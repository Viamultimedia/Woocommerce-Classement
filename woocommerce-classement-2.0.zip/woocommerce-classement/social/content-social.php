<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


function via_classement_woocommerce_content_social() { ?>

<div class="options-via-woocommerce-classement-title-right">
	<div class="options-via-woocommerce-classement-reseaux-sociaux">
		<a target="_blank" class="templify-lien-facebook" href="https://www.viamultimedia.ca/"><i class="fa fa-bookmark-o" aria-hidden="true"></i></a>
		<a target="_blank" class="templify-lien-facebook" href="https://www.viamultimedia.ca/membres/"><i class="fa fa-server" aria-hidden="true"></i></a>
		<a target="_blank" class="templify-lien-facebook" href="https://www.facebook.com/viamultimediatr/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
		<a target="_blank" class="templify-lien-twitter" href="https://twitter.com/viamultimediaQC"><i class="fa fa-twitter" aria-hidden="true"></i></a>
		<!--<a target="_blank" class="templify-lien-you-tube" href=""><i class="fa fa-youtube" aria-hidden="true"></i></a>-->
		<a target="_blank" class="templify-lien-you-linkedin" href="https://ca.linkedin.com/in/viamultimedia"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
	</div>
</div>
<?php         
}