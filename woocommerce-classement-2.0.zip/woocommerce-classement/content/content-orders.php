<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results Orders /////////////////////////////////////////////

function tab_results_orders() { ?>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Total', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_orders_all(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('This Week', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_orders_semaine(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Today', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_orders_jour(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Finished', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_completed(); ?> -<?php echo via_classement_woocommerce_total_orders_completed(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Waiting for payment', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_statut('wc-pending'); ?> -<?php echo via_classement_woocommerce_total_orders_paiement(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('In progress', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_statut('wc-processing'); ?> -<?php echo via_classement_woocommerce_total_orders_attente(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Cancelled', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_statut('wc-cancelled'); ?> -<?php echo via_classement_woocommerce_total_orders_cancelled(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Refunded', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_statut('wc-refunded'); ?> -<?php echo via_classement_woocommerce_total_orders_refunded(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Failed', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_statut('wc-failed'); ?> -<?php echo via_classement_woocommerce_total_orders_failed(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('List / Month', 'woocommerce-classement'); ?></h2>
		<p><?php _e('Coming soon', 'woocommerce-classement'); ?><?php //echo via_classement_woocommerce_total_orders_by_date(); ?></p>
	</div>
	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('List / Day', 'woocommerce-classement'); ?></h2>
		<p><?php _e('Coming soon', 'woocommerce-classement'); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Statutes Orders', 'woocommerce-classement'); ?></h2>
		<p><?php _e('Coming soon', 'woocommerce-classement'); ?><?php //echo via_classement_woocommerce_get_order_statuses(); ?></p>
	</div> 
	
	<div class="col span_8_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('All Orders', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_list_orders_all(); ?></p>
	</div> 
	
	<div class="via-woocommerce-classement-clear"></div>
	
<?php } 