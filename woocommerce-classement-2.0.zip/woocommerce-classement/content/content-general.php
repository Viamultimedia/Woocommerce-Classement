<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results General ////////////////////////////////////////////


function tab_results_general() { ?>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Turnover', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells(); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Finished sales', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_completed(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Number Sold Items', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_items_sold(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Finished Orders', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_orders_all(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Total products', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_count_total(); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Sales this Year', 'woocommerce-classement'); ?></h2>
		<p>
			<?php $echocurentdate = date("Y"); echo via_classement_woocommerce_total_sells_by_year_result_general($echocurentdate); ?>
			<?php _e('&nbsp;', 'woocommerce-classement'); ?>
			<?php echo comparatif_pourcent_ventes_year(); ?>
		</p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Sales last Year', 'woocommerce-classement'); ?></h2>
		<p><?php $echocurentdate = date('Y', strtotime('-1 year')); echo via_classement_woocommerce_total_sells_by_year_result_general($echocurentdate); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Sales this Month', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_by_month_result_general(); ?><?php echo comparatif_pourcent_ventes_mensuel(); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Sales last Month', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_by_last_month_result_general(); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Sales Today', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_by_day_result_general(); ?> <?php echo comparatif_pourcent_ventes_jour(); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Sales Yesterday', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_sells_yesterday_result_general(); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Total Coupons', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_coupons(); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Total Customers', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_user_registred(); ?></p>
	</div>

	<div class="via-woocommerce-classement-clear"></div>
	
<?php } 