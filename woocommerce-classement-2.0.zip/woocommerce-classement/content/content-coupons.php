<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results Coupons ////////////////////////////////////////////

function tab_results_coupons() { ?>
    
	<div class="col span_2_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Total', 'woocommerce-classement' ); ?></h2>
		<p><?php echo via_classement_woocommerce_total_coupons(); ?></p>
	</div>

	<div class="col span_2_of_8"> 
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('This week', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_coupons_semaine(); ?></p>
	</div>

	<div class="col span_2_of_8"> 
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Today', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_coupons_jour(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Pending', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_coupons_en_ligne($statut = 'draft'); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Published list', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_coupons_by_title('publish'); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Pending list', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_coupons_by_title('draft');  ?></p>
	</div>

	<div class="via-woocommerce-classement-clear"></div>
	
<?php } 