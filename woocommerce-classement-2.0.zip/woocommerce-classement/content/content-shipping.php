<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results General ////////////////////////////////////////////


function tab_results_livraison() { ?>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Total Sales Shipping', 'woocommerce-classement' ); ?></h2>
		<p>
		<?php echo via_classement_woocommerce_get_total_shipping(); ?>
		</p>
	</div>

	<div class="via-woocommerce-classement-clear"></div>
	
<?php } 