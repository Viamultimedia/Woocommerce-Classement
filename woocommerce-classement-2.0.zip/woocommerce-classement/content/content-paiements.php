<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results General ////////////////////////////////////////////


function tab_results_paiements() { ?>
	
	<div class="col span_8_of_8">
		<h2><i class="fa fa-bullhorn" aria-hidden="true"></i> <?php _e('Payments Report', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_get_paiements_way() ?></p>
	</div>

	<div class="via-woocommerce-classement-clear"></div>
	
<?php } 