<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results Products ///////////////////////////////////////////


function tab_results_products() { ?>
    
	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Total Products', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_count_total(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Published Products / week', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_publish_week(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Products Published Today', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_publish_day(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Number Categories', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_count_categories(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Number of Products / Categories', 'woocommerce-classement'); ?></h2>
		<p><?php echo results_modal_products_category(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Featured / In Stock', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_list_featured_in_stock(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Featured / Out Stock', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_list_featured_out_stock(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('In Stock', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_list_in_stock(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Out Stock', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_list_out_stock(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Best Sellers', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_products_classement_total_sells(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('Best Ranked', 'woocommerce-classement'); ?></h2>
		<p><?php _e('Coming soon', 'woocommerce-classement'); ?><?php //echo via_classement_woocommerce_products_classement_total_rating(); ?></p>
	</div>
	
	<div class="col span_8_of_8">
		<h2><i class="fa fa-check" aria-hidden="true"></i> <?php _e('List of the last products ordered', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_get_list_products_orders(); ?></p>
	</div>

	<div class="via-woocommerce-classement-clear"></div>

<?php } 

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results Products Category //////////////////////////////////

function results_modal_products_category() { ?>

	<!-- Trigger/Open The Modal -->
	<button id="modalcategories"><?php _e('View', 'woocommerce-classement'); ?></button>

	<!-- The Modal -->
	<div id="Modalcategories" class="modal">

	<!-- Modal content -->
	<div class="modal-content">
	<span class="close">×</span>
	<?php echo via_classement_woocommerce_products_count_category(); ?>
	</div>

	</div>
	
<?php } 




