<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Navigation TABS ////////////////////////////////////////////


function via_classement_woocommerce_tabs_navigation() { ?>
	
	<ul class="resp-tabs-list hor_1">
		<li id="tabs-1" class="tabs-1">
			<i class="fc_icons fa fa-dashboard"></i> 
			<span class="tabs-text">
			<?php _e('Dashboard', 'woocommerce-classement'); ?>
			</span>
		</li>
		<li id="tabs-2" class="tabs-2">
			<i class="fc_icons fa fa-google-wallet"></i> 
			<span class="tabs-text">
			<?php _e('Objectives', 'woocommerce-classement'); ?>
			</span>
		</li>
		<li id="tabs-3" class="tabs-3">
			<i class="fc_icons fa fa-line-chart"></i> 
			<span class="tabs-text">
			<?php _e('Top Graphs', 'woocommerce-classement'); ?>
			</span>
		</li>
		
		<li id="tabs-4" class="tabs-4">
			<i class="fc_icons fa fa-bullhorn"></i> 
			<span class="tabs-text">
			<?php _e('Résults', 'woocommerce-classement'); ?>
			</span>
		</li>
		<li id="tabs-5" class="tabs-5">
			<i class="fc_icons fa fa-user"></i> 
			<span class="tabs-text">
			<?php _e('Customers', 'woocommerce-classement'); ?>
			</span>
		</li>
		<li id="tabs-6" class="tabs-6">
			<i class="fc_icons fa fa-list-ol"></i> 
			<span class="tabs-text">
			<?php _e('Orders', 'woocommerce-classement'); ?>
			</span>
		</li>             
		<li id="tabs-7"class="tabs-7">
			<i class="fc_icons fa fa-check"></i> 
			<span class="tabs-text">
			<?php _e('Products', 'woocommerce-classement'); ?>
			</span>
		</li>
		<li id="tabs-8" class="tabs-8">
			<i class="fc_icons fa fa-codiepie"></i> 
			<span class="tabs-text"><?php _e('Coupons', 'woocommerce-classement'); ?>
			</span>
		</li>
		<li id="tabs-9" class="tabs-9">
			<i class="fc_icons fa fa-ship"></i> 
			<span class="tabs-text"><?php _e('Shipping', 'woocommerce-classement'); ?>
			</span>
		</li>
		<li id="tabs-10"class="tabs-10">
			<i class="fc_icons fa fa-paypal"></i> 
			<span class="tabs-text">
			<?php _e('Payments', 'woocommerce-classement'); ?>
			</span>
		</li>
		<li id="tabs-11" class="tabs-11">
			<i class="fc_icons fa fa-envelope"></i> 
			<span class="tabs-text"><?php _e('Plugin', 'woocommerce-classement'); ?></span> 
		</li>
		<!--<li id="tabs-11" class="tabs-12">
			<i class="fc_icons fa fa-cart"></i> 
			<span class="tabs-text"><?php _e('Queries', 'woocommerce-classement'); ?></span> 
		</li>-->
	</ul> 
	
<?php } 