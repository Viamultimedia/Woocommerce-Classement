<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results Products ///////////////////////////////////////////


function tab_results_queries() { ?>

	<div class="via-woocommerce-classement-clear"></div>
	
	<?php $options = get_option('via_woocommerce_classement_settings'); if ( isset($options['via_woocommerce_classement_queries_by_product_id']) && ($options['via_woocommerce_classement_queries_by_product_id'] != '') ){ ?>
	<div class="col span_8_of_8">
		<h2><i class="fa fa-list-ol" aria-hidden="true"></i> <?php _e('Orders By ID Product', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_list_orders_by_id(); ?></p>
	</div> 
	
	<div class="via-woocommerce-classement-clear"></div>
	
	<?php } else { ?>
	
	<p>
	    <?php _e( 'No orders currently', 'woocommerce-classement'); ?>
	</p>
		
	<?php } ?>
	
<?php } 
