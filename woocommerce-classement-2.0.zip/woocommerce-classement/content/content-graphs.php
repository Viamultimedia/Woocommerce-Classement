<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results plugin /////////////////////////////////////////////


function tab_results_graphs() { ?>

	<div class="col span_8_of_8">

	<h2><i class="fa fa-line-chart" aria-hidden="true"></i> <?php _e('Top Graphs', 'woocommerce-classement' ); ?></h2>

		<?php $options = get_option('via_woocommerce_classement_settings'); if ( isset($options['via_woocommerce_classement_checkbox_annee_2017']) && ($options['via_woocommerce_classement_checkbox_annee_2017'] == 1) ){ ?>
		
		<!-- css bar graph -->
		<div class="mensuel_css_bar_graph">
			
			<!-- y_axis labels -->
			<ul class="y_axis">
				<li><?php $sum = chiffre_affaire_graph($pourcent = '100', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '90', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '80', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '70', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '60', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '50', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '40', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '30', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '20', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '10', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '0', $divisible); echo $sum; ?></li>
			</ul>
			
			<!-- x_axis labels -->
			<ul class="x_axis">
				<li><?php _e('Jan'); ?></li>
				<li><?php _e('Feb'); ?></li>
				<li><?php _e('Mar'); ?></li>
				<li><?php _e('Apr'); ?></li>
				<li><?php _e('May'); ?></li>
				<li><?php _e('Jun'); ?></li>
				<li><?php _e('Jul'); ?></li>
				<li><?php _e('Aug'); ?></li>
				<li><?php _e('Sep'); ?></li>
				<li><?php _e('Oct'); ?></li>
				<li><?php _e('Nov'); ?></li>
				<li><?php _e('Dec'); ?></li>
			</ul> 
			
			<!-- graph -->
			<div class="graph">
				<!-- grid -->
				<ul class="grid">
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
				</ul>
				
				<!-- bars -->
				<!-- 250px = 100% -->
				
				<ul>
					<li class="bar nr_1 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='01'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='01', $day='1'); ?></span></li>
					<li class="bar nr_2 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='02'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='02', $day='1'); ?></span></li>
					<li class="bar nr_3 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='03'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='03', $day='1'); ?></span></li>
					<li class="bar nr_4 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='04'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='04', $day='1'); ?></span></li>
					<li class="bar nr_5 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='05'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='05', $day='1'); ?></span></li>
					<li class="bar nr_6 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='06'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='06', $day='1'); ?></span></li>
					<li class="bar nr_7 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='07'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='07', $day='1'); ?></span></li>
					<li class="bar nr_8 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='08'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='08', $day='1'); ?></span></li>
					<li class="bar nr_9 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='09'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='09', $day='1'); ?></span></li>
					<li class="bar nr_10 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='10'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='10', $day='1'); ?></span></li>
					<li class="bar nr_11 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='11'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='11', $day='1'); ?></span></li>
					<li class="bar nr_12 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2017', $month='12'); ?>;"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2017',$month='12', $day='1'); ?></span></li>
				</ul>	
			</div>
			
			<!-- graph label -->
			<div class="label"><span><?php _e('Résults :', 'woocommerce-classement'); ?> </span><?php _e('Monthly comparison of Turnover', 'woocommerce-classement'); ?> <?php _e('2017', 'woocommerce-classement'); ?></div>
		
		</div>
		
		<div class="via-woocommerce-classement-clear"></div>
		
		<?php } else { ?>
		
		<?php } ?>
		
		<?php $options = get_option('via_woocommerce_classement_settings'); if ( isset($options['via_woocommerce_classement_checkbox_annee_2016']) && ($options['via_woocommerce_classement_checkbox_annee_2016'] == 1) ){ ?>
		
		<!-- css bar graph -->
		<div class="mensuel_css_bar_graph">
			
			<!-- y_axis labels -->
			<ul class="y_axis">
				<li><?php $sum = chiffre_affaire_graph($pourcent = '100', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '90', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '80', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '70', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '60', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '50', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '40', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '30', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '20', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '10', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '0', $divisible); echo $sum; ?></li>
			</ul>
			
			<!-- x_axis labels -->
			<ul class="x_axis">
				<li><?php _e('Jan'); ?></li>
				<li><?php _e('Feb'); ?></li>
				<li><?php _e('Mar'); ?></li>
				<li><?php _e('Apr'); ?></li>
				<li><?php _e('May'); ?></li>
				<li><?php _e('Jun'); ?></li>
				<li><?php _e('Jul'); ?></li>
				<li><?php _e('Aug'); ?></li>
				<li><?php _e('Sep'); ?></li>
				<li><?php _e('Oct'); ?></li>
				<li><?php _e('Nov'); ?></li>
				<li><?php _e('Dec'); ?></li>
			</ul> 
			
			<!-- graph -->
			<div class="graph">
				<!-- grid -->
				<ul class="grid">
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
				</ul>
				
				<!-- bars -->
				<!-- 250px = 100% -->
				
				<ul>
					<li class="bar nr_1 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='01'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='01', $day='1'); ?></span></li>
					<li class="bar nr_2 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='02'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='02', $day='1'); ?></span></li>
					<li class="bar nr_3 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='03'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='03', $day='1'); ?></span></li>
					<li class="bar nr_4 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='04'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='04', $day='1'); ?></span></li>
					<li class="bar nr_5 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='05'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='05', $day='1'); ?></span></li>
					<li class="bar nr_6 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='06'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='06', $day='1'); ?></span></li>
					<li class="bar nr_7 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='07'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='07', $day='1'); ?></span></li>
					<li class="bar nr_8 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='08'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='08', $day='1'); ?></span></li>
					<li class="bar nr_9 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='09'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='09', $day='1'); ?></span></li>
					<li class="bar nr_10 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='10'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='10', $day='1'); ?></span></li>
					<li class="bar nr_11 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='11'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='11', $day='1'); ?></span></li>
					<li class="bar nr_12 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2016', $month='12'); ?>;"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2016',$month='12', $day='1'); ?></span></li>
				</ul>	
			</div>
			
			<!-- graph label -->
			<div class="label"><span><?php _e('Résults :', 'woocommerce-classement'); ?> </span><?php _e('Monthly comparison of Turnover', 'woocommerce-classement'); ?> <?php _e('2016', 'woocommerce-classement'); ?></div>
		
		</div>
		
		<div class="via-woocommerce-classement-clear"></div>
		
		<?php } else { ?>
		
		<?php } ?>
		
		<?php $options = get_option('via_woocommerce_classement_settings'); if ( isset($options['via_woocommerce_classement_checkbox_annee_2015']) && ($options['via_woocommerce_classement_checkbox_annee_2015'] == 1) ){ ?>
		
		<!-- css bar graph -->
		<div class="mensuel_css_bar_graph">
			
			<!-- y_axis labels -->
			<ul class="y_axis">
				<li><?php $sum = chiffre_affaire_graph($pourcent = '100', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '90', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '80', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '70', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '60', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '50', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '40', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '30', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '20', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '10', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph($pourcent = '0', $divisible); echo $sum; ?></li>
			</ul>
			
			<!-- x_axis labels -->
			<ul class="x_axis">
				<li><?php _e('Jan'); ?></li>
				<li><?php _e('Feb'); ?></li>
				<li><?php _e('Mar'); ?></li>
				<li><?php _e('Apr'); ?></li>
				<li><?php _e('May'); ?></li>
				<li><?php _e('Jun'); ?></li>
				<li><?php _e('Jul'); ?></li>
				<li><?php _e('Aug'); ?></li>
				<li><?php _e('Sep'); ?></li>
				<li><?php _e('Oct'); ?></li>
				<li><?php _e('Nov'); ?></li>
				<li><?php _e('Dec'); ?></li>
			</ul> 
			
			<!-- graph -->
			<div class="graph">
				<!-- grid -->
				<ul class="grid">
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
					<li><!-- 100 --></li>
				</ul>
				
				<!-- bars -->
				<!-- 250px = 100% -->
				
				<ul>
					<li class="bar nr_1 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='01'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='01', $day='1'); ?></span></li>
					<li class="bar nr_2 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='02'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='02', $day='1'); ?></span></li>
					<li class="bar nr_3 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='03'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='03', $day='1'); ?></span></li>
					<li class="bar nr_4 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='04'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='04', $day='1'); ?></span></li>
					<li class="bar nr_5 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='05'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='05', $day='1'); ?></span></li>
					<li class="bar nr_6 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='06'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='06', $day='1'); ?></span></li>
					<li class="bar nr_7 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='07'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='07', $day='1'); ?></span></li>
					<li class="bar nr_8 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='08'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='08', $day='1'); ?></span></li>
					<li class="bar nr_9 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='09'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='09', $day='1'); ?></span></li>
					<li class="bar nr_10 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='10'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='10', $day='1'); ?></span></li>
					<li class="bar nr_11 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='11'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='11', $day='1'); ?></span></li>
					<li class="bar nr_12 <?php via_classement_woocommerce_get_color_graphique_regular(); ?>" style="height: <?php echo resultspourcentmonth($year='2015', $month='12'); ?>;"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_month($year='2015',$month='12', $day='1'); ?></span></li>
				</ul>	
			</div>
			
			<!-- graph label -->
			<div class="label"><span><?php _e('Résults :', 'woocommerce-classement'); ?> </span><?php _e('Monthly comparison of Turnover', 'woocommerce-classement'); ?> <?php _e('2015', 'woocommerce-classement'); ?></div>
		
		</div>
		
		<div class="via-woocommerce-classement-clear"></div>
		
		<?php } else { ?>
		
		<?php } ?>
		
		<?php $options = get_option('via_woocommerce_classement_settings'); if ( isset($options['via_woocommerce_classement_checkbox_comparatif_annuel']) && ($options['via_woocommerce_classement_checkbox_comparatif_annuel'] == 1) ){ ?>
		
		<!-- css bar graph -->
		<div class="graph_compare_chiffre">
			
			<!-- y_axis labels -->
			<ul class="y_axis">
				<li><?php $sum = chiffre_affaire_graph_comparatif_annuel($pourcent = '100', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph_comparatif_annuel($pourcent = '80', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph_comparatif_annuel($pourcent = '60', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph_comparatif_annuel($pourcent = '40', $divisible); echo $sum; ?></li>
				<li><?php $sum = chiffre_affaire_graph_comparatif_annuel($pourcent = '20', $divisible); echo $sum; ?></li>
			</ul>
			
			<!-- x_axis labels -->
			<ul class="x_axis">
				<li><?php _e('2017'); ?></li>
				<li><?php _e('2016'); ?></li>
				<li><?php _e('2015'); ?></li>
				<li><?php _e('2014'); ?></li>
				<li><?php _e('2013'); ?></li>
			</ul>
			
			<!-- graph -->
			<div class="graph">
				<!-- grid -->
				<ul class="grid">
					<li><!-- 100 --></li>
					<li><!-- 80 --></li>
					<li><!-- 60 --></li>
					<li><!-- 40 --></li>
					<li><!-- 20 --></li>
					<li class="bottom"><!-- 0 --></li>
				</ul>
				
				<!-- bars -->
				<!-- 250px = 100% -->
				<ul>
					<li class="bar nr_1 green" style="height: <?php echo resultspourcentyear($year='2017'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year($year='2017'); ?></span></li>
					<li class="bar nr_2 red" style="height: <?php echo resultspourcentyearrefunded($year='2017'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year_refunded($year='2017'); ?></span></li>
					<li class="bar nr_3 green" style="height: <?php echo resultspourcentyear($year='2016'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year($year='2016'); ?></span></li>
					<li class="bar nr_4 red" style="height: <?php echo resultspourcentyearrefunded($year='2016'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year_refunded($year='2016'); ?></span></li>
					<li class="bar nr_5 green" style="height: <?php echo resultspourcentyear($year='2015'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year($year='2015'); ?></span></li>
					<li class="bar nr_6 red" style="height: <?php echo resultspourcentyearrefunded($year='2015'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year_refunded($year='2015'); ?></span></li>
					<li class="bar nr_7 green" style="height: <?php echo resultspourcentyear($year='2014'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year($year='2014'); ?></span></li>
					<li class="bar nr_8 red" style="height: <?php echo resultspourcentyearrefunded($year='2014'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year_refunded($year='2014'); ?></span></li>
					<li class="bar nr_9 green" style="height: <?php echo resultspourcentyear($year='2013'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year($year='2013'); ?></span></li>
					<li class="bar nr_10 red" style="height: <?php echo resultspourcentyearrefunded($year='2013'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year_refunded($year='2013'); ?></span></li>
				</ul>	
			</div>
			
			<!-- graph label -->
			<div class="label">
				<span><?php _e('Résults :', 'woocommerce-classement'); ?> </span><?php _e('Comparison of sales over the last five years', 'woocommerce-classement'); ?><br />
				<span><?php _e('Green :', 'woocommerce-classement'); ?> </span><?php _e('Finished', 'woocommerce-classement'); ?> <b><?php _e('Sales', 'woocommerce-classement'); ?></b><br />
				<span><?php _e('Red :', 'woocommerce-classement'); ?> </span><?php _e('Refunded','woocommerce-classement'); ?> <b><?php _e('Sales', 'woocommerce-classement'); ?></b>
			</div>
			<div class="via-woocommerce-classement-clear"></div>
		
		</div>
		
		<div class="via-woocommerce-classement-clear"></div>
		
		<?php } else { ?>
		
		<?php } ?>

	</div>

	<div class="via-woocommerce-classement-clear"></div>

<?php } 