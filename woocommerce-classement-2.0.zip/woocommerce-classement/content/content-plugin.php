<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results plugin /////////////////////////////////////////////


function tab_content_plugin() { ?>
	
	<div class="options-via-woocommerce-classement-wrap">
		<div class="col span_4_of_8">
			<h2><i class="fa fa-envelope" aria-hidden="true"></i> 
			<?php _e('The Plugin', 'woocommerce-classement'); ?></h2>
			<p>
			<?php _e('Current Version', 'woocommerce-classement'); ?> 
			<?php _e('-' ); ?> <?php $version = '2.0'; echo $version; ?>
			</p>
		</div>

		<div class="col span_4_of_8">
			<h2><i class="fa fa-envelope" aria-hidden="true"></i> <?php _e('Contact Us', 'woocommerce-classement'); ?></h2>
			<p><?php _e('Want to contact us ?', 'woocommerce-classement' ); ?></p>
			<a href="mailto:infos@viamultimedia.ca" target="_top"><?php _e('Email', 'woocommerce-classement'); ?></a>
		</div>

		<div class="via-woocommerce-classement-clear"></div>
	</div>
	
<?php }