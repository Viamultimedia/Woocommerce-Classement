<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results Products ///////////////////////////////////////////


function tab_results_tableau_bord() { ?>

	<div class="col span_8_of_8">
		<?php echo via_woocommerce_classement_options_page(); ?>
	</div>
	<div class="via-woocommerce-classement-clear"></div>
	
<?php } 
