<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results Customers //////////////////////////////////////////

function tab_results_customers() { ?>
    
	<div class="col span_2_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Total', 'woocommerce-classement' ); ?></h2>
		<p><?php echo via_classement_woocommerce_total_user_registred(); ?></p>
	</div>
	
	<div class="col span_2_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Registred this Year', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_user_registred_year(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Registred this Month', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_user_registred_month(); ?></p>
	</div>

	<div class="col span_2_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Registred today', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_total_user_registred_day(); ?></p>
	</div>
	
	<div class="col span_8_of_8">
		<h2><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Orders Count by Customer', 'woocommerce-classement'); ?></h2>
		<p><?php echo via_classement_woocommerce_list_customers_results($user_id); ?></p>
	</div>

	<div class="via-woocommerce-classement-clear"></div>
	
<?php } 
