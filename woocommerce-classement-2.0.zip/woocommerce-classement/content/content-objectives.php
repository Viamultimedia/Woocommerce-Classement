<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Results Customers //////////////////////////////////////////

function tab_results_objectifs() { ?>

	<div class="col span_8_of_8">
		
		<h2><i class="fa fa-line-chart" aria-hidden="true"></i> <?php _e('Objectives', 'woocommerce-classement' ); ?></h2>
		
		<?php $options = get_option('via_woocommerce_classement_settings'); if ( isset($options['via_woocommerce_classement_checkbox_annee_2017']) && ($options['via_woocommerce_classement_checkbox_annee_2017'] == 1) ){ ?>
		
		<div class="div-vingt"></div>
		
		<h3 class="woocommerceclassementtitleobjectifs"><?php _e('2017', 'woocommerce-classement'); ?></h3>
			<!-- css bar graph -->
			<div class="objectif_css_bar_graph">
				
				<!-- y_axis labels -->
				<ul class="y_axis">
					<li><?php echo '100%'; ?></li>
					<li><?php echo '80%'; ?></li>
					<li><?php echo '60%'; ?></li>
					<li><?php echo '40%'; ?></li>
					<li><?php echo '20%'; ?></li>
					<li><?php echo '0%'; ?></li>
				</ul>
				
				<!-- x_axis labels -->
				<ul class="x_axis">
					<li><?php _e('Sales', 'woocommerce-classement'); ?></li>
					<li><?php _e('Customers', 'woocommerce-classement'); ?></li>
					<li><?php _e('Orders', 'woocommerce-classement'); ?></li>
					<li><?php _e('Coupons', 'woocommerce-classement'); ?></li>
					<li><?php _e('Shipping', 'woocommerce-classement'); ?></li>
				</ul>
				
				<!-- graph -->
				<div class="graph">
					<!-- grid -->
					<ul class="grid">
						<li><!-- 100 --></li>
						<li><!-- 80 --></li>
						<li><!-- 60 --></li>
						<li><!-- 40 --></li>
						<li><!-- 20 --></li>
						<li class="bottom"><!-- 0 --></li>
					</ul>
					
					<!-- bars -->
					<!-- 250px = 100% -->
					<ul>
						<li class="bar nr_1 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifsventes('2017'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year($year='2017'); ?></span></li>
						<li class="bar nr_2 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifsclients('2017'); ?>"><div class="top"></div><div class="bottom"></div><?php echo via_classement_woocommerce_total_user_registred('2017'); ?></li>
						<li class="bar nr_3 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifscommandes('2017'); ?>"><div class="top"></div><div class="bottom"></div><?php echo via_classement_woocommerce_total_orders_all_year('2017'); ?></li>
						<li class="bar nr_4 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifscoupons('2017'); ?>"><div class="top"></div><div class="bottom"></div><?php echo via_classement_woocommerce_total_coupons_year('2017'); ?></li>
						<li class="bar nr_5 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifsshipping('2017'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_get_total_shipping_annuel('2017'); ?></span></li>
					</ul>	
				</div>
				
				<div class="via-woocommerce-classement-clear"></div>
		
				<!-- graph label -->
				<div class="label"><span>Objectives : </span><?php _e('Results of your Objectives (% Variation)', 'woocommerce-classement'); ?><br />
					<div class="div-vingt"></div>
					<span><?php _e('Sales :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_ventes']; ?> <?php  echo get_woocommerce_currency_symbol(); ?><br />
					<span><?php _e('Customers :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_clients']; ?><br />
					<span><?php _e('Orders :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_commandes']; ?><br />
					<span><?php _e('Coupons :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_coupons']; ?><br />
					<span><?php _e('Shipping :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_shipping']; ?> <?php echo get_woocommerce_currency_symbol(); ?><br />
				</div>
			</div>
			
		<div class="via-woocommerce-classement-clear"></div>

		<?php } else { ?>
		
		<?php } ?>
		
		<?php $options = get_option('via_woocommerce_classement_settings'); if ( isset($options['via_woocommerce_classement_checkbox_annee_2016']) && ($options['via_woocommerce_classement_checkbox_annee_2016'] == 1) ){ ?>
		
		<h3 class="woocommerceclassementtitleobjectifs"><?php _e('2016' ); ?></h3>
			
			<!-- css bar graph -->
			<div class="objectif_css_bar_graph">
				
				<!-- y_axis labels -->
				<ul class="y_axis">
					<li><?php echo '100%'; ?></li>
					<li><?php echo '80%'; ?></li>
					<li><?php echo '60%'; ?></li>
					<li><?php echo '40%'; ?></li>
					<li><?php echo '20%'; ?></li>
					<li><?php echo '0%'; ?></li>
				</ul>
				
				<!-- x_axis labels -->
				<ul class="x_axis">
					<li><?php _e('Sales', 'woocommerce-classement'); ?></li>
					<li><?php _e('Customers', 'woocommerce-classement'); ?></li>
					<li><?php _e('Orders', 'woocommerce-classement'); ?></li>
					<li><?php _e('Coupons', 'woocommerce-classement'); ?></li>
					<li><?php _e('Shipping', 'woocommerce-classement'); ?></li>
				</ul>
				
				<!-- graph -->
				<div class="graph">
					<!-- grid -->
					<ul class="grid">
						<li><!-- 100 --></li>
						<li><!-- 80 --></li>
						<li><!-- 60 --></li>
						<li><!-- 40 --></li>
						<li><!-- 20 --></li>
						<li class="bottom"><!-- 0 --></li>
					</ul>
					
					<!-- bars -->
					<!-- 250px = 100% -->
					<ul>
						<li class="bar nr_1 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifsventes('2016'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_total_sells_by_year($year='2016'); ?></span></li>
						<li class="bar nr_2 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifsclients('2016'); ?>"><div class="top"></div><div class="bottom"></div><?php echo via_classement_woocommerce_total_user_registred('2016'); ?></li>
						<li class="bar nr_3 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifscommandes('2016'); ?>"><div class="top"></div><div class="bottom"></div><?php echo via_classement_woocommerce_total_orders_all_year('2016'); ?></li>
						<li class="bar nr_4 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifscoupons('2016'); ?>"><div class="top"></div><div class="bottom"></div><?php echo via_classement_woocommerce_total_coupons_year('2016'); ?></li>
						<li class="bar nr_5 <?php get_color_graphique_objectifs(); ?>" style="height: <?php echo resultspourcentyearobjectifsshipping('2016'); ?>"><div class="top"></div><div class="bottom"></div><span class="numberCircle"><?php echo via_classement_woocommerce_get_total_shipping_annuel('2016'); ?></span></li>
					</ul>	
				</div>
				
				<!-- graph label -->
				<div class="label"><span><?php _e('Objectives : '); ?> </span><?php _e('Results of your Objectives (% Variation)', 'woocommerce-classement'); ?><br />
					<div class="div-vingt"></div>
					<span><?php _e('Sales :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_ventes']; ?> <?php echo get_woocommerce_currency_symbol(); ?><br />
					<span><?php _e('Customers :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_clients']; ?><br />
					<span><?php _e('Orders :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_commandes']; ?><br />
					<span><?php _e('Coupons :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_coupons']; ?><br />
					<span><?php _e('Shipping :', 'woocommerce-classement'); ?> </span> <?php $options = get_option('via_woocommerce_classement_settings'); echo $options ['via_woocommerce_classement_objectifs_shipping']; ?> <?php echo get_woocommerce_currency_symbol(); ?><br />
				<div class="via-woocommerce-classement-clear"></div>
				</div>
			</div>
			
		<div class="via-woocommerce-classement-clear"></div>
		
		<div class="div-vingt"></div>
		
		<?php } else { ?>
		
		<?php } ?>
		
	</div>

	<div class="via-woocommerce-classement-clear"></div>

<?php } 