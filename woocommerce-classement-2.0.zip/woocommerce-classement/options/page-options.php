<?php
add_action( 'admin_init', 'via_woocommerce_classement_settings_init' );

function via_woocommerce_classement_settings_init(  ) { 

	register_setting( 'viawoocommerceclassementPage', 'via_woocommerce_classement_settings' );
	register_setting( 'viawoocommerceclassementObjectifs', 'via_woocommerce_classement_settings' );
	register_setting( 'viawoocommerceclassementUsers', 'via_woocommerce_classement_settings' );
	register_setting( 'viawoocommerceclassementProducts', 'via_woocommerce_classement_settings' );

	add_settings_section(
		'via_woocommerce_classement_viawoocommerceclassementPage_section', 
		__( '<i class="fa fa-pencil" aria-hidden="true"></i> Options', 'woocommerce-classement' ), 
		'via_woocommerce_classement_settings_section_callback', 
		'viawoocommerceclassementPage'
	);
	
	add_settings_section(
		'via_woocommerce_classement_viawoocommerceclassementObjectifs_section', 
		__( '<i class="fc_icons fa fa-google-wallet"></i> Objectives', 'woocommerce-classement' ), 
		'via_woocommerce_classement_settings_section__objectifs_callback', 
		'viawoocommerceclassementObjectifs'
	);
	
	add_settings_section(
		'via_woocommerce_classement_viawoocommerceclassementUsers_section', 
		__( '<i class="fc_icons fa fa-user"></i> Users', 'woocommerce-classement' ), 
		'via_woocommerce_classement_settings_section_users_callback', 
		'viawoocommerceclassementUsers'
	);
	
	add_settings_section(
		'via_woocommerce_classement_viawoocommerceclassementProducts_section', 
		__( '<i class="fc_icons fa fa-cart"></i> Products', 'woocommerce-classement' ), 
		'via_woocommerce_classement_settings_section_products_callback', 
		'viawoocommerceclassementProducts'
	);
	
	add_settings_field( 
		'via_woocommerce_classement_objectifs_color_graphique', 
		__( 'Color of Graphics (Objectives)', 'woocommerce-classement' ), 
		'via_woocommerce_classement_objectifs_color_graphique_render', 
		'viawoocommerceclassementObjectifs', 
		'via_woocommerce_classement_viawoocommerceclassementObjectifs_section' 
	);

	add_settings_field( 
		'via_woocommerce_classement_chiffre_affaires', 
		__( 'Monthly Sales Limit (Graphs)', 'woocommerce-classement' ), 
		'via_woocommerce_classement_chiffre_affaires_render', 
		'viawoocommerceclassementPage', 
		'via_woocommerce_classement_viawoocommerceclassementPage_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_chiffre_affaires_comparatif_annuel', 
		__( 'Annual Sales limit (Graphs)', 'woocommerce-classement' ), 
		'via_woocommerce_classement_chiffre_affaires_comparatif_annuel_render', 
		'viawoocommerceclassementPage', 
		'via_woocommerce_classement_viawoocommerceclassementPage_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_objectifs_ventes', 
		__( 'Sales Objectives (Graphs)', 'woocommerce-classement' ), 
		'via_woocommerce_classement_objectifs_ventes_render', 
		'viawoocommerceclassementObjectifs', 
		'via_woocommerce_classement_viawoocommerceclassementObjectifs_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_objectifs_clients', 
		__( 'Customer Objectives (Graph)', 'woocommerce-classement' ), 
		'via_woocommerce_classement_objectifs_clients_render', 
		'viawoocommerceclassementObjectifs', 
		'via_woocommerce_classement_viawoocommerceclassementObjectifs_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_objectifs_commandes', 
		__( 'Objectives Orders (Graph)', 'woocommerce-classement' ), 
		'via_woocommerce_classement_objectifs_commandes_render', 
		'viawoocommerceclassementObjectifs', 
		'via_woocommerce_classement_viawoocommerceclassementObjectifs_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_objectifs_coupons', 
		__( 'Coupon Targets (Graph)', 'woocommerce-classement' ), 
		'via_woocommerce_classement_objectifs_coupons_render', 
		'viawoocommerceclassementObjectifs', 
		'via_woocommerce_classement_viawoocommerceclassementObjectifs_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_objectifs_shipping', 
		__( 'Objectives Shipping (Graph)', 'woocommerce-classement' ), 
		'via_woocommerce_classement_objectifs_shipping_render', 
		'viawoocommerceclassementObjectifs', 
		'via_woocommerce_classement_viawoocommerceclassementObjectifs_section' 
	);

	add_settings_field( 
		'via_woocommerce_classement_checkbox_annee_2017', 
		__( 'Chart for 2017 ?', 'woocommerce-classement' ), 
		'via_woocommerce_classement_checkbox_annee_2017_render', 
		'viawoocommerceclassementPage', 
		'via_woocommerce_classement_viawoocommerceclassementPage_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_checkbox_annee_2016', 
		__( 'Chart for 2016 ?', 'woocommerce-classement' ), 
		'via_woocommerce_classement_checkbox_annee_2016_render', 
		'viawoocommerceclassementPage', 
		'via_woocommerce_classement_viawoocommerceclassementPage_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_checkbox_annee_2015', 
		__( 'Chart for 2015 ?', 'woocommerce-classement' ), 
		'via_woocommerce_classement_checkbox_annee_2015_render', 
		'viawoocommerceclassementPage', 
		'via_woocommerce_classement_viawoocommerceclassementPage_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_checkbox_comparatif_annuel', 
		__( 'Annual Comparisons ?', 'woocommerce-classement' ), 
		'via_woocommerce_classement_checkbox_comparatif_annuel_render', 
		'viawoocommerceclassementPage', 
		'via_woocommerce_classement_viawoocommerceclassementPage_section' 
	);

	add_settings_field( 
		'via_woocommerce_classement_textarea_objectifs_employes', 
		__( 'Comments for Employees', 'woocommerce-classement' ), 
		'via_woocommerce_classement_textarea_objectifs_employes_render', 
		'viawoocommerceclassementObjectifs', 
		'via_woocommerce_classement_viawoocommerceclassementObjectifs_section' 
	);

	add_settings_field( 
		'via_woocommerce_classement_select_couleurs_graphs', 
		__( 'Choice of color of Graphs', 'woocommerce-classement' ), 
		'via_woocommerce_classement_select_couleurs_graphs_render', 
		'viawoocommerceclassementPage', 
		'via_woocommerce_classement_viawoocommerceclassementPage_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_users_loyal_count', 
		__( 'Count Orders to be a Loyal Customer ( be > 1 )', 'woocommerce-classement' ), 
		'via_woocommerce_classement_users_loyal_count_render', 
		'viawoocommerceclassementUsers', 
		'via_woocommerce_classement_viawoocommerceclassementUsers_section' 
	);
	
	add_settings_field( 
		'via_woocommerce_classement_queries_by_product_id', 
		__( 'Display Orders by Product ID', 'woocommerce-classement' ), 
		'via_woocommerce_classement_queries_by_product_id_render', 
		'viawoocommerceclassementProducts', 
		'via_woocommerce_classement_viawoocommerceclassementProducts_section' 
	);

}


function via_woocommerce_classement_chiffre_affaires_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_chiffre_affaires]' value='<?php echo $options['via_woocommerce_classement_chiffre_affaires']; ?>'>
	<?php
}

function via_woocommerce_classement_chiffre_affaires_comparatif_annuel_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_chiffre_affaires_comparatif_annuel]' value='<?php echo $options['via_woocommerce_classement_chiffre_affaires_comparatif_annuel']; ?>'>
	<?php
}

function via_woocommerce_classement_objectifs_ventes_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_objectifs_ventes]' value='<?php echo $options['via_woocommerce_classement_objectifs_ventes']; ?>'>
	<?php
}

function via_woocommerce_classement_objectifs_clients_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_objectifs_clients]' value='<?php echo $options['via_woocommerce_classement_objectifs_clients']; ?>'>
	<?php
}

function via_woocommerce_classement_objectifs_commandes_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_objectifs_commandes]' value='<?php echo $options['via_woocommerce_classement_objectifs_commandes']; ?>'>
	<?php
}

function via_woocommerce_classement_objectifs_coupons_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_objectifs_coupons]' value='<?php echo $options['via_woocommerce_classement_objectifs_coupons']; ?>'>
	<?php
}

function via_woocommerce_classement_objectifs_shipping_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_objectifs_shipping]' value='<?php echo $options['via_woocommerce_classement_objectifs_shipping']; ?>'>
	<?php
}


function via_woocommerce_classement_checkbox_annee_2017_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<label class="switch">
	<input class='switch-input' type='checkbox' name='via_woocommerce_classement_settings[via_woocommerce_classement_checkbox_annee_2017]' <?php checked( $options['via_woocommerce_classement_checkbox_test_2017'], 1 ); ?> value='1' <?php if ( 1 == $options['via_woocommerce_classement_checkbox_annee_2017'] ) echo 'checked="checked"'; ?>>
	<span class="switch-label" data-on="<?php _e('Yes'); ?>" data-off="<?php _e('No'); ?>"></span> 
	<span class="switch-handle"></span> 
	</label>
	
	<?php
}

function via_woocommerce_classement_checkbox_annee_2016_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<label class="switch">
	<input class='switch-input' type='checkbox' name='via_woocommerce_classement_settings[via_woocommerce_classement_checkbox_annee_2016]' <?php checked( $options['via_woocommerce_classement_checkbox_test_2016'], 1 ); ?> value='1' <?php if ( 1 == $options['via_woocommerce_classement_checkbox_annee_2016'] ) echo 'checked="checked"'; ?>>
	<span class="switch-label" data-on="<?php _e('Yes'); ?>" data-off="<?php _e('No'); ?>"></span> 
	<span class="switch-handle"></span> 
	</label>
	<?php
}

function via_woocommerce_classement_checkbox_annee_2015_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<label class="switch">
	<input class='switch-input' type='checkbox' name='via_woocommerce_classement_settings[via_woocommerce_classement_checkbox_annee_2015]' <?php checked( $options['via_woocommerce_classement_checkbox_test_2015'], 1 ); ?> value='1' <?php if ( 1 == $options['via_woocommerce_classement_checkbox_annee_2015'] ) echo 'checked="checked"'; ?>>
	<span class="switch-label" data-on="<?php _e('Yes'); ?>" data-off="<?php _e('No'); ?>"></span> 
	<span class="switch-handle"></span> 
	</label>
	
	<?php
}

function via_woocommerce_classement_checkbox_comparatif_annuel_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<label class="switch">
	<input class='switch-input' type='checkbox' name='via_woocommerce_classement_settings[via_woocommerce_classement_checkbox_comparatif_annuel]' <?php checked( $options['via_woocommerce_classement_checkbox_comparatif_annuel'], 1 ); ?> value='1' <?php if ( 1 == $options['via_woocommerce_classement_checkbox_comparatif_annuel'] ) echo 'checked="checked"'; ?>>
	<span class="switch-label" data-on="<?php _e('Yes'); ?>" data-off="<?php _e('No'); ?>"></span> 
	<span class="switch-handle"></span> 
	</label>
	
	<?php
}


function via_woocommerce_classement_objectifs_color_graphique_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<div class="select-style" style="width:100%">
		<select  style="width:100%" name='via_woocommerce_classement_settings[via_woocommerce_classement_objectifs_color_graphique]'>
			<option value='1' <?php selected( $options['via_woocommerce_classement_objectifs_color_graphique'], 1 ); ?>><?php _e('Green'); ?></option>
			<option value='2' <?php selected( $options['via_woocommerce_classement_objectifs_color_graphique'], 2 ); ?>><?php _e('Blue'); ?></option>
			<option value='3' <?php selected( $options['via_woocommerce_classement_objectifs_color_graphique'], 3 ); ?>><?php _e('Red'); ?></option>
		</select>
	</div>
	<?php
}

function via_woocommerce_classement_textarea_objectifs_employes_render(  ) { 
    $options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<textarea style="width:100%" name='via_woocommerce_classement_settings[via_woocommerce_classement_textarea_objectifs_employes]'><?php echo $options['via_woocommerce_classement_textarea_objectifs_employes']; ?></textarea>
	<?php
}


function via_woocommerce_classement_select_couleurs_graphs_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<div class="select-style" style="width:100%">
		<select  style="width:100%" name='via_woocommerce_classement_settings[via_woocommerce_classement_select_couleurs_graphs]'>
			<option value='1' <?php selected( $options['via_woocommerce_classement_select_couleurs_graphs'], 1 ); ?>><?php _e('Green'); ?></option>
			<option value='2' <?php selected( $options['via_woocommerce_classement_select_couleurs_graphs'], 2 ); ?>><?php _e('Blue'); ?></option>
			<option value='3' <?php selected( $options['via_woocommerce_classement_select_couleurs_graphs'], 3 ); ?>><?php _e('Red'); ?></option>
		</select>
	</div>
	<?php
}

function via_woocommerce_classement_users_loyal_count_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_users_loyal_count]' value='<?php echo $options['via_woocommerce_classement_users_loyal_count']; ?>'>
	<?php
}

function via_woocommerce_classement_queries_by_product_id_render(  ) { 
	$options = get_option( 'via_woocommerce_classement_settings' );
	?>
	<input style="width:100%" type="text" name='via_woocommerce_classement_settings[via_woocommerce_classement_queries_by_product_id]' value='<?php echo $options['via_woocommerce_classement_queries_by_product_id']; ?>'>
	<?php
}


function via_woocommerce_classement_settings_section_callback(  ) { 
echo __( 'Configure statistical options Via Woocommerce Classement', 'woocommerce-classement' );
}

function via_woocommerce_classement_settings_section__objectifs_callback(  ) { 
echo __( 'Configure the objectives of your Company', 'woocommerce-classement' );
}

function via_woocommerce_classement_settings_section_users_callback(  ) { 
echo __( '<div class="comingsoon">');
echo __( 'Configure options for Customers - Coming Soon', 'woocommerce-classement' );
echo __( '</div>');
}

function via_woocommerce_classement_settings_section_products_callback(  ) { 
echo __( 'Configuration of Products Settings', 'woocommerce-classement' );
}

function via_woocommerce_classement_options_page(  ) { ?>
	
	<div class="wrap">
	
	<div class="options-via-woocommerce-classement">

	
		<div class="options-via-woocommerce-classement-wrap">
			
			<div class="col span_5_of_8">
			
				<div class="col span_8_of_8">
				
					<form action='options.php' method='post'>
				
						<?php
						// Echo errors ou options sauvegardees
						settings_errors();
						settings_fields( 'viawoocommerceclassementPage' );
						do_settings_sections( 'viawoocommerceclassementPage' );
						do_settings_sections( 'viawoocommerceclassementObjectifs' );
						//do_settings_sections( 'viawoocommerceclassementUsers' );
						//do_settings_sections( 'viawoocommerceclassementProducts' );
						submit_button();
						?>

					</form>
				
				</div>
				
			</div>
			
			<div class="col span_3_of_8">
			
				<h2>
					<i class="fa fa-envelope" aria-hidden="true"></i> 
					<?php _e('Informations', 'woocommerce-classement' ); ?>
				</h2>
				<p>
				<?php _e('Woocommerce Classement is an extension that allows you to get statistics from your Woocommerce Online Store.', 'woocommerce-classement' ); ?>
				</p>
				
				<p>
				<?php _e('Thank you for your purchase !', 'woocommerce-classement' ); ?>
				</p>
				
				<div class="via-woocommerce-classement-clear"></div>
				
				<h2>
					<i class="fa fa-envelope" aria-hidden="true"></i> 
					<?php _e('Updates', 'woocommerce-classement' ); ?>
				</h2>
					<ul style="max-width:100%; padding-left:20px;">
						<li><?php _e('1 - ', 'woocommerce-classement' ); ?> 
						<?php _e('Last updated on 21 November 2016', 'woocommerce-classement'); ?>
						</li>
						<li><?php _e('2 - ', 'woocommerce-classement' ); ?>
						<?php _e('Chart 2017 added', 'woocommerce-classement'); ?>
						</li>
					</ul> 
			</div>
			
			<div class="via-woocommerce-classement-clear"></div>
			
		</div>
	
	</div>
	
	</div>
<?php
}


