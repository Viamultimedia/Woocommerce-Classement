<?php

/*
Plugin Name: Woocommerce Classement
Plugin URI: https://viamultimedia.ca/
Description: Plugin featuring statistics from your Woocommerce Online Store.
Version: 2.0
Author: Viamultimedia
Author URI: https://www.viamultimedia.ca/
*/ 

/*  
Copyright 2011-2016 Tony Breboin (email:infos@viamultimedia.ca)
License: Single Site
*/


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**************************************** Load folders Language ************************************/

function  via_woocommerce_classement_load_plugin_textdomain() {
	$domain = 'woocommerce-classement';
	$locale = apply_filters( 'plugin_locale', get_locale(), $domain );
	if ( $loaded = load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' ) ) {
		return $loaded;
	} else {
		load_plugin_textdomain( $domain, FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
	}
}
add_action( 'init', 'via_woocommerce_classement_load_plugin_textdomain' );

/******************** Load Settings and Site Link to plugin links presentation *********************/

add_filter( 'plugin_action_links', 'via_classement_woocommerce_add_action_plugin', 10, 5 );
function via_classement_woocommerce_add_action_plugin( $actions, $plugin_file ) 
{
	static $plugin;

	if (!isset($plugin))
		$plugin = plugin_basename(__FILE__);
	if ($plugin == $plugin_file) {

			$settings = array('settings' => '<a href="admin.php?page=via-woocommerce-classement">' . __('Settings', 'General') . '</a>');
			$site_link = array('support' => '<a href="https://viamultimedia.ca/" target="_blank">Support</a>');
		
    			$actions = array_merge($settings, $actions);
				$actions = array_merge($site_link, $actions);
			
		}
		
		return $actions;
}

/********************************  Load folders pages of the plugin *******************************/

include( plugin_dir_path( __FILE__ ) . 'admin/admin-functions.php');
include( plugin_dir_path( __FILE__ ) . 'admin/plugin-functions.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-graphs.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-objectives.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-dashboard.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-general.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-customers.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-products.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-orders.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-plugin.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-tabs-navigation.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-coupons.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-shipping.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-paiements.php');
include( plugin_dir_path( __FILE__ ) . 'content/content-queries.php');
include( plugin_dir_path( __FILE__ ) . 'social/content-social.php');
include( plugin_dir_path( __FILE__ ) . 'options/page-options.php');

///////////////////////////////////////////// Enqueue Styles Admin /////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function via_classement_woocommerce_wp_admin_style() { 
    wp_register_style( 'viastyle', plugins_url('/css/style.css', __FILE__), false, '1.0.0', 'all');
	wp_enqueue_style( 'viastyle' );
	wp_register_style( 'via-classement', plugins_url('/css/admin.css', __FILE__), false, '1.0.0', 'all');
	wp_enqueue_style( 'via-classement' );
	wp_register_style( 'via-responsive', plugins_url('/css/responsive.css', __FILE__), false, '1.0.0', 'all');
	wp_enqueue_style( 'via-responsive' );
	//wp_register_style( 'animatemin', plugins_url('/css/animate.min.css', __FILE__), false, '1.0.0', 'all');
	//wp_enqueue_style( 'animatemin' );
	wp_register_style( 'easyresponsive', plugins_url('/css/easy-responsive-tabs.min.css', __FILE__), false, '1.0.0', 'all');
	wp_enqueue_style( 'easyresponsive' );
	wp_register_style( 'tabs', plugins_url('/css/tabs.css', __FILE__), false, '1.0.0', 'all');
	wp_enqueue_style( 'tabs' );
	wp_register_style( 'graphs', plugins_url('/css/graphs.css', __FILE__), false, '1.0.0', 'all');
	wp_enqueue_style( 'graphs' );
}
add_action( 'admin_enqueue_scripts', 'via_classement_woocommerce_wp_admin_style' );

///////////////////////////////////////////// Enqueue JS Admin /////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

add_action('admin_enqueue_scripts', 'register_script');
function register_script() { 
	wp_register_script( 'easyResponsiveTabs', plugins_url('/js/easyResponsiveTabs.js', __FILE__), true ); 
	wp_register_script( 'jquerynicescrollmin', plugins_url('/js/jquery.nicescroll.min.js', __FILE__), true );  
	wp_register_script( 'tabs', plugins_url('/js/tabs.js', __FILE__), true );  
	wp_register_script( 'modal', plugins_url('/js/modal.js', __FILE__), true );  
}

add_action('admin_footer', 'enqueue_style');
function enqueue_style(){ 
	wp_enqueue_script('easyResponsiveTabs');
	wp_enqueue_script('jquerynicescrollmin');
	wp_enqueue_script('tabs'); 
	wp_enqueue_script('modal');  
}

///////////////////////////////////////////// Enqueue JS Admin /////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//enqueues our external font awesome stylesheet
function via_classement_woocommerce_wp_admin_awesome(){
wp_enqueue_style('font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css'); 
}
add_action('admin_enqueue_scripts','via_classement_woocommerce_wp_admin_awesome');

/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	
	function via_classement_woocommerce_submenu_page() {
		add_submenu_page( 'woocommerce', 'Woocommerce Classement', 'Woocommerce Classement', 'manage_options', 'via-woocommerce-classement', 'woocommerce_classement_submenu_page_callback' ); 
	}
	
	function woocommerce_classement_submenu_page_callback() {  ?>
	
		<div class="wrap">
				
		<div class="options-via-woocommerce-classement">
				
		<h1><?php _e('Woocommerce Classement'); ?> <?php _e('-' ); ?> <?php $version = '2.0'; echo $version; ?></h1>
		
		<!-- Begin wrap div -->
		<div class="options-via-woocommerce-classement-wrap">
					
	    <!-- Begin HorizontalTab style 1 -->
		<section class="section-full dark-bg">

			<div class="container">

				<div class="row">

					<div class="col-md-12">
						
						<!-- Begin .HorizontalTab -->
						<div class="VerticalTab fc_VerticalTab VerticalTab_1 tabs_ver_1">
						
						<?php echo via_classement_woocommerce_tabs_navigation(); ?>
							
							<div class="resp-tabs-container hor_1">
								
								<div class="fc-tab-1">
								
								    <?php echo tab_results_tableau_bord(); ?>
									
								</div>
								
								<div class="fc-tab-2">
								
								    <?php echo tab_results_objectifs(); ?>
									
								</div>
								
								<div class="fc-tab-3">
								
								    <?php echo tab_results_graphs(); ?>
									
								</div>
								
								<div class="fc-tab-4">
								
								    <?php echo tab_results_general(); ?>
									
								</div>
								
								<div class="fc-tab-5">
								   
								    <?php echo tab_results_customers(); ?>
									
								</div>
								
								<div class="fc-tab-6">
								
									<?php echo tab_results_orders(); ?>
									 
								</div>
								
								<div class="fc-tab-7">
								
									<?php echo tab_results_products(); ?>
									 
								</div>
								
								<div class="fc-tab-8">
								
									<?php echo tab_results_coupons(); ?>
									 
								</div>
								
								<div class="fc-tab-9">
								
									<?php echo tab_results_livraison(); ?>
									 
								</div>
								
								<div class="fc-tab-10">
								
									<?php echo tab_results_paiements(); ?>
									 
								</div>
								
								<div class="fc-tab-11">
								
									<?php echo tab_content_plugin(); ?>
									 
								</div>
								
								<!--<div class="fc-tab-12">
								
									<?php //echo tab_results_queries(); ?>
									 
								</div>-->
							
							</div>
							
						</div>
						<!-- End .HorizontalTab -->
					
					</div>
					
				</div>
				
			</div>

		</section>
		<!-- End HorizontalTab style 1 -->
						
		<div class="via-woocommerce-classement-clear"></div>
		
	
		</div>
		<!-- End wrap div -->
		
		<?php echo via_classement_woocommerce_content_social(); ?>
				
		</div>
				
		</div>
		
	<?php
	}
	add_action('admin_menu', 'via_classement_woocommerce_submenu_page',99);
}