<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                             // Chiffres d'affaires / Functions Total Sells //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function via_classement_woocommerce_total_sells_completed() {
	global $wpdb; 
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed' ) ) . "' )
	" ) );
	echo '<span class="numberCircle">';
	echo '&nbsp;';
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
	echo '</span>';
}

function via_classement_woocommerce_total_sells() {
	global $wpdb;
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	" ) );
	echo '<span class="numberCircle">';
	echo '&nbsp;';
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
	echo '</span>';
}

function via_classement_woocommerce_total_sells_by_month($year, $month, $day) {
	global $wpdb;
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$year-$month-$day 00:00:00' AND '$year-$month-31 00:00:00'
	" ) );
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
}

function via_classement_woocommerce_total_sells_by_month_result_general($month) {
	global $wpdb;
	$year = date('Y');
	$month = date('m');
	$day = date('d');
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$year-$month-01 00:00:00' AND '$year-$month-31 00:00:00'
	" ) );
	echo '<span class="numberCircle">';
	echo '&nbsp;';
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
    echo '</span>';
}

function via_classement_woocommerce_total_sells_by_last_month_result_general($month) {
	global $wpdb;
	$year = date('Y');
	$month = date('m', strtotime('-30 days'));
	$day = date('d');
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$year-$month-01 00:00:00' AND '$year-$month-31 00:00:00'
	" ) );
	echo '<span class="numberCircle">';
	echo '&nbsp;';
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
    echo '</span>';
}

function via_classement_woocommerce_total_sells_by_day_result_general() {
	global $wpdb;
	$today = date('Y-m-d');
	$tomorrow  = date('Y-m-d', strtotime('+24 hours'));
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$today 00:00:00' AND '$tomorrow 00:00:00'
	" ) );
	echo '<span class="numberCircle">';
	echo '&nbsp;';
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol();
    echo '</span>';
}

function via_classement_woocommerce_total_sells_yesterday_result_general() {
	global $wpdb;
	$today = date('Y-m-d');
	$yesterday = date('Y-m-d',strtotime("-1 days"));
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$yesterday 00:00:00' AND '$today 00:00:00'
	" ) );
	echo '<span class="numberCircle">';
	echo '&nbsp;';
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
    echo '</span>';
}

function via_classement_woocommerce_total_sells_by_year_result_general($year) {
	global $wpdb;
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$year-01-01 00:00:00' AND '$year-12-31 00:00:00'
	" ) );
	echo '<span class="numberCircle">';
	echo '&nbsp;';
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
    echo '</span>';
}

function via_classement_woocommerce_total_sells_by_year($year) {
	global $wpdb;
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$year-01-01 00:00:00' AND '$year-12-31 00:00:00'
	" ) );
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
}

function via_classement_woocommerce_total_sells_by_year_refunded($year) {
	global $wpdb;
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-refunded' ) ) . "' )
	AND posts.post_date BETWEEN '$year-01-01 00:00:00' AND '$year-12-31 00:00:00'
	" ) );
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
}


function via_classement_woocommerce_total_sells_statut($statut) {
	global $wpdb;
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( $statut ) ) . "' )
	" ) );
	echo '<span class="numberCircle">';
	echo '&nbsp;';
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
	echo '</span>';
}

function via_classement_woocommerce_items_sold() {
	global $wpdb;
	$result = $wpdb->get_row("
	SELECT SUM(pm.meta_value) AS total_sales
	FROM $wpdb->posts AS p
	LEFT JOIN $wpdb->postmeta AS pm ON (p.ID = pm.post_id AND pm.meta_key = 'total_sales') 
	WHERE p.post_type = 'product'
	"); 
	echo '<span class="numberCircle">';
	return $result->total_sales;
	echo '</span>';
	echo '&nbsp; Ventes';
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                             // Functions Clients //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function via_classement_woocommerce_total_user_registred($year) {
	global $wpdb;
	$user_query = new WP_User_Query( array( 
	'role' => 'Customer',
	'date_query' => array( 
		array( 'year' => date( $year )  
	))	
	) );
	$users_count = (int) $user_query->get_total();
	// Echo a string and the value
	echo '<span class="numberCircle">';
	echo '' . $users_count;
	echo '</span>';
}

function via_classement_woocommerce_total_user_registred_graphique($year) {
	global $wpdb;
	// Get all users with role Author.
	$user_query = new WP_User_Query( array( 
	'role' => 'Customer',
		'date_query' => array( 
		array( 'year' => date( $year )  
	))	
	) );
	// Get the total number of users for the current query. I use (int) only for sanitize.
	$users_count = (int) $user_query->get_total();
	// Echo a string and the value
	return $users_count;	
}

function via_classement_woocommerce_total_user_registred_year() {
	global $wpdb;
	// Get all users with role Author.
	$user_query = new WP_User_Query( array( 
	'role' => 'Customer',
		'date_query' => array( 
		array( 'year' => date( $year )  
	))	
	) );
	// Get the total number of users for the current query. I use (int) only for sanitize.
	$users_count = (int) $user_query->get_total();
	// Echo a string and the value
	echo '<span class="numberCircle">';
	return $users_count;
    echo '</span>';	
}

function via_classement_woocommerce_total_user_registred_month() {
	////  en travail /////////////////////////////////////////////////////
    $user_query = new WP_User_Query( $args );
	global $wpdb;
	$date = getdate();
	$user_count = $wpdb->get_var( "SELECT COUNT(*) FROM $wpdb->users WHERE MONTH(user_registered) = $date[mon] AND YEAR(user_registered) = $date[year]" );
	echo '<span class="numberCircle">';
	echo "{$user_count}";
	echo '</span>';
}

/////////////////////////// En travail /////////////////////////////////////////

function via_classement_woocommerce_total_user_registred_day() {
    ////  en travail ///////////////////////////////////////////////////////////////////
	global $wpdb;
	$query = "SELECT COUNT(ID) FROM {$wpdb->prefix}users WHERE DATE(user_registered) = CURDATE()";
	if ( $activated ) {
        $query .= " AND user_status = 0";
    }
    echo '<span class="numberCircle">';
    return $wpdb->get_var($query);
	echo '</span>';
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                             // Functions Products //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function via_classement_woocommerce_products_count_categories() {
$product_cat_count = wp_count_terms( 'product_cat' );
echo '<span class="numberCircle">';
echo $product_cat_count;
echo '</span>';
}   

function via_classement_woocommerce_products_count_total() {
    $args = array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => -1 );
	$products = new WP_Query( $args );
	echo '<span class="numberCircle">';
	echo $products->found_posts;
	echo '</span>';
}

function via_classement_woocommerce_products_publish_week( $args = '' ) {
	global $wpdb;
	$defaults = array(
		'echo' => 1,
		'days' => 7,
		'lookahead' => 0
	);
	$the_args = wp_parse_args( $args, $defaults );
	extract( $the_args , EXTR_SKIP );
	unset( $args , $the_args , $defaults );
	$days = intval( $days );
	$operator = ( $lookahead != false ) ? '+' : '-';
	$postsindays = $wpdb->get_col( "
		SELECT COUNT(ID)
		FROM $wpdb->posts
		WHERE (1=1
		AND post_type = 'product'
		AND post_status = 'publish'
		AND post_date >= '" . date('Y-m-d', strtotime("$operator$days days")) . "')"
	);
		if($echo != false) :
			echo '<span class="numberCircle">';
			echo $postsindays[0];
			echo '</span>';
		else :
			echo '<span class="numberCircle">';
			return $postsindays[0];
			echo '</span>';
		endif;
	return;
}

function via_classement_woocommerce_products_publish_day( $args = '' ) {
	global $wpdb;
	$defaults = array(
		'echo' => 1,
		'days' => 1,
		'lookahead' => 0
	);
	$the_args = wp_parse_args( $args, $defaults );
	extract( $the_args , EXTR_SKIP );
	unset( $args , $the_args , $defaults );
	$days = intval( $days );
	$operator = ( $lookahead != false ) ? '+' : '-';
	$postsindays = $wpdb->get_col( "
		SELECT COUNT(ID)
		FROM $wpdb->posts
		WHERE (1=1
		AND post_type = 'product'
		AND post_status = 'publish'
		AND post_date >= '" . date('Y-m-d', strtotime("$operator$days days")) . "')"
	);
		if($echo != false) :
		    echo '<span class="numberCircle">';
			echo $postsindays[0];
			echo '</span>';
		else :
		    echo '<span class="numberCircle">';
			return $postsindays[0];
			echo '</span>';
		endif;
	return;
}

function via_classement_woocommerce_products_count_category() {
	$terms = get_terms( 'product_cat' );
		foreach( $terms as $term ) 
		{
			echo '<div class="col span_2_of_8">'
				. $term->name
				. '&nbsp;-&nbsp;'
				. $term->count .'&nbsp;' 
				. __('Products', 'woocmmerce-classement')
				. '</div>';
		} 
	echo '<div class="via-woocommerce-classement-clear"></div>';
}

//////////////////// en travail /////////////////////////////////////
function via_classement_woocommerce_products_list_featured_in_stock() { ?>
	<?php
	$params = array(
			'posts_per_page' => 5, 
			'post_type' => array('product', 'product_variation'),
			'meta_key' => '_featured',
			'meta_value' => 'yes',
			'meta_query' => array(
				array(
					'key' => '_stock_status',
					'value' => 'instock'
				)
			)
	);
	$wc_query = new WP_Query($params); 
	?>
	<?php if ($wc_query->have_posts()) : ?>
	<?php while ($wc_query->have_posts()) :
					$wc_query->the_post(); ?>
	<span class="span-color-results"><?php the_title(); ?></span>
	<br />
	<?php endwhile; ?>
	<?php wp_reset_postdata(); ?>
	<?php else:  ?>
	<p>
		 <?php _e( 'No products currently', 'woocommerce-classement'); ?>
	</p>
	<?php endif; ?>
<?php
}

//////////////////// en travail /////////////////////////////////////
function via_classement_woocommerce_products_list_featured_out_stock() { ?>
	<?php
	$params = array(
			'posts_per_page' => 5, 
			'post_type' => array('product', 'product_variation'),
			'meta_key' => '_featured',
			'meta_value' => 'yes',
			'meta_query' => array(
				array(
					'key' => '_stock_status',
					'value' => 'outofstock'
				)
			)
	);
	$wc_query = new WP_Query($params); 
	?>
	<?php if ($wc_query->have_posts()) : ?>
	<?php while ($wc_query->have_posts()) :
					$wc_query->the_post(); ?>
	<span class="span-color-results"><?php the_title(); ?></span>
	<br />
	<?php endwhile; ?>
	<?php wp_reset_postdata(); ?>
	<?php else:  ?>
	<p>
		 <?php _e( 'No products currently', 'woocommerce-classement'); ?>
	</p>
	<?php endif; ?>
	<?php
	}

	//////////////////// en travail /////////////////////////////////////
	function via_classement_woocommerce_products_list_in_stock() { ?>
	<?php
	$params = array(
			'posts_per_page' => 5, 
			'post_type' => array('product', 'product_variation'),
			'meta_query' => array(
				array(
					'key' => '_price',
					'type' => 'NUMERIC'
				),
				array(
					'key' => '_stock_status',
					'value' => 'instock'
				)
			)
	);
	$wc_query = new WP_Query($params);
	?>
	<?php if ($wc_query->have_posts()) : ?>
	<?php while ($wc_query->have_posts()) : 
					$wc_query->the_post(); ?>
	<span class="span-color-results"><?php the_title(); ?></span>
	<br />
	<?php endwhile; ?>
	<?php wp_reset_postdata(); ?>
	<?php endif; ?>
<?php
}

//////////////////// en travail /////////////////////////////////////
function via_classement_woocommerce_products_list_out_stock() { ?>
	<?php
	$params = array(
			'posts_per_page' => 5, 
			'post_type' => array('product', 'product_variation'),
			'meta_query' => array(
				array(
					'key' => '_price',
					'type' => 'NUMERIC'
				),
				array(
					'key' => '_stock_status',
					'value' => 'outofstock'
				)
			)
	);
	$wc_query = new WP_Query($params); 
	?>
	<?php if ($wc_query->have_posts()) : ?>
	<?php while ($wc_query->have_posts()) :
					$wc_query->the_post(); ?>
	<span class="span-color-results"><?php the_title(); ?></span>
	<br />
	<?php endwhile; ?>
	<?php wp_reset_postdata(); ?>
	<?php else:  ?>
	<p>
		 <?php _e( 'No products currently', 'woocommerce-classement'); ?>
	</p>
	<?php endif; ?>
<?php
}



//////////////////// en travail /////////////////////////////////////

function via_classement_woocommerce_products_classement_total_sells() { ?>
	
	<?php
	$i = 1;
	$semaine = new WP_Query( array( 
	'post_type' => array('product', 'product_variation'),
	'post_status' => 'publish',
	'meta_key' => 'total_sales',
	'orderby' => 'meta_value_num',
	'showposts'  => '5',		
	'order' => 'DESC', 
	));
	while ( $semaine->have_posts() ) : $semaine->the_post();
	?>
	 <span class="span-color-results"> <?php echo $i; ?> <?php _e('-'); ?> <?php the_title(); ?></span>
	<br />
	<?php $i++; ?>
	<?php wp_reset_query(); ?>
	<?php endwhile; ?>
	<?php //echo '<a href="#">+</a>'; ?>
<?php        
}


//////////////////// en travail /////////////////////////////////////

function via_classement_woocommerce_products_classement_total_rating() { ?>
	
	<?php
	$i = 1;
	$semaine = new WP_Query( array( 
	'post_type' => array('product', 'product_variation'),
	'post_status' => 'publish',
	'meta_key' => '_rating',
	'orderby' => 'meta_value_num',
	'showposts'  => '5',		
	'order' => 'DESC', 
	));
	while ( $semaine->have_posts() ) : $semaine->the_post();
	?>
	<?php echo $i; ?> <?php _e('-'); ?> <span class="span-color-results"><?php the_title(); ?></span>
	<br />
	<?php $i++; ?>
	<?php wp_reset_query(); ?>
	<?php endwhile; ?>
	 <a href="#">+</a> 
<?php        
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                             // Functions Orders //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function via_classement_woocommerce_get_order_statuses() {
  $order_statuses = get_terms( 'shop_order_status', array( 'hide_empty' => false ) );
  $statuses = array();
  foreach ( $order_statuses as $status ) {
    $statuses[ $status->slug ] = $status->name;
  }
  echo $statuses;
}

function via_classement_woocommerce_total_orders_completed() {
	$args = ( array(
		'status' => 'wc-completed',
	));
	$statuses    = array_map( 'trim', explode( ',', $args['status'] ) );
	$order_count = 0;
	foreach ( $statuses as $status ) {
		// if we didn't get a wc- prefix, add one
		if ( 0 !== strpos( $status, 'wc-completed' ) ) {
			$status = str_replace( $status, 'wc-completed' . $status, $status );
		}
		$total_orders = wp_count_posts( 'shop_order' )->$status;
		$order_count += $total_orders;
	}
	ob_start();
	echo '<span class="numberCircle">';
	echo number_format( $order_count );
	echo '</span>';
	return ob_get_clean();
}

function via_classement_woocommerce_total_orders_paiement() {
	$args = ( array(
		'status' => 'wc-pending',
	));
	$statuses    = array_map( 'trim', explode( ',', $args['status'] ) );
	$order_count = 0;
	foreach ( $statuses as $status ) {
		// if we didn't get a wc- prefix, add one
		if ( 0 !== strpos( $status, 'wc-pending' ) ) {
			$status = str_replace( $status, 'wc-pending' . $status, $status );
		}
		$total_orders = wp_count_posts( 'shop_order' )->$status;
		$order_count += $total_orders;
	}
	ob_start();
	echo '<span class="numberCircle">';
	echo number_format( $order_count );
	echo '</span>';
	return ob_get_clean();
}

function via_classement_woocommerce_total_orders_attente() {
	$args = ( array(
		'status' => 'wc-processing',
	));
	$statuses    = array_map( 'trim', explode( ',', $args['status'] ) );
	$order_count = 0;
	foreach ( $statuses as $status ) {
		// if we didn't get a wc- prefix, add one
		if ( 0 !== strpos( $status, 'wc-processing' ) ) {
			$status = str_replace( $status, 'wc-processing' . $status, $status );
		}
		$total_orders = wp_count_posts( 'shop_order' )->$status;
		$order_count += $total_orders;
	}
	ob_start();
	echo '<span class="numberCircle">';
	echo number_format( $order_count );
	echo '</span>';
	return ob_get_clean();
}

function via_classement_woocommerce_total_orders_all() {
	$args = ( array(
		'status' => 'wc-completed',
	));
	$statuses    = array_map( 'trim', explode( ',', $args['status'] ) );
	$order_count = 0;
	foreach ( $statuses as $status ) {
		// if we didn't get a wc- prefix, add one
		if ( 0 !== strpos( $status, 'wc-completed' ) ) {
			$status = str_replace( $status, 'wc-completed' . $status, $status );
		}
		$total_orders = wp_count_posts( 'shop_order' )->$status;
		$order_count += $total_orders;
	}
	ob_start();
	echo '<span class="numberCircle">';
	echo number_format( $order_count );
	echo '</span>';
	return ob_get_clean();
}

function via_classement_woocommerce_total_orders_all_year($year) { ?>
	<?php
	$semaine = new WP_Query( array( 
	'post_type' => 'shop_order', 
	'post_status' => 'publish',
	'posts_per_page'  => -1,			
	'orderby' => 'date', 
	'order' => 'DESC', 
	   'date_query' => array( 
		array( 'year' => date( $year )  
	))	
	));
	$num = $semaine->post_count; 
	echo'<span class="numberCircle">';
	echo $num;
	echo'</span>'; 
}


function via_classement_woocommerce_total_orders_all_graphique($year) { ?>
	<?php
	$semaine = new WP_Query( array( 
	'post_type' => 'shop_order', 
	'post_status' => 'wc-completed',
	'posts_per_page'  => -1,			
	'orderby' => 'date', 
	'order' => 'DESC', 
	   'date_query' => array( 
		array( 'year' => date( $year )  
	))	
	));
	$num = $semaine->post_count; 
	return $num;
}

function via_classement_woocommerce_total_orders_cours() {
	$args = ( array(
		'status' => 'wc-on-hold',
	));
	$statuses    = array_map( 'trim', explode( ',', $args['status'] ) );
	$order_count = 0;
	foreach ( $statuses as $status ) {
		// if we didn't get a wc- prefix, add one
		if ( 0 !== strpos( $status, 'wc-on-hold' ) ) {
			$status = str_replace( $status, 'wc-on-hold' . $status, $status );
		}
		$total_orders = wp_count_posts( 'shop_order' )->$status;
		$order_count += $total_orders;
	}
	ob_start();
	echo '<span class="numberCircle">';
	echo number_format( $order_count );
	echo '</span>';
	return ob_get_clean();
}

function via_classement_woocommerce_total_orders_cancelled() {
	$args = ( array(
		'status' => 'wc-cancelled',
	));
	$statuses    = array_map( 'trim', explode( ',', $args['status'] ) );
	$order_count = 0;
	foreach ( $statuses as $status ) {
		// if we didn't get a wc- prefix, add one
		if ( 0 !== strpos( $status, 'wc-cancelled' ) ) {
			$status = str_replace( $status, 'wc-cancelled' . $status, $status );
		}
		$total_orders = wp_count_posts( 'shop_order' )->$status;
		$order_count += $total_orders;
	}
	ob_start();
	echo '<span class="numberCircle">';
	echo number_format( $order_count );
	echo '</span>';
	return ob_get_clean();
}

function via_classement_woocommerce_total_orders_refunded() {
	$args = ( array(
		'status' => 'wc-refunded',
	));
	$statuses    = array_map( 'trim', explode( ',', $args['status'] ) );
	$order_count = 0;
	foreach ( $statuses as $status ) {
		// if we didn't get a wc- prefix, add one
		if ( 0 !== strpos( $status, 'wc-refunded' ) ) {
			$status = str_replace( $status, 'wc-refunded' . $status, $status );
		}
		$total_orders = wp_count_posts( 'shop_order' )->$status;
		$order_count += $total_orders;
	}
	ob_start();
	echo '<span class="numberCircle">';
	echo number_format( $order_count );
	echo '</span>';
	return ob_get_clean();
}


function via_classement_woocommerce_total_orders_failed() {
	$args = ( array(
		'status' => 'wc-failed',
	));
	$statuses    = array_map( 'trim', explode( ',', $args['status'] ) );
	$order_count = 0;
	foreach ( $statuses as $status ) {
		// if we didn't get a wc- prefix, add one
		if ( 0 !== strpos( $status, 'wc-failed' ) ) {
			$status = str_replace( $status, 'wc-failed' . $status, $status );
		}
		$total_orders = wp_count_posts( 'shop_order' )->$status;
		$order_count += $total_orders;
	}
	ob_start();
	echo '<span class="numberCircle">';
	echo number_format( $order_count );
	echo '</span>';
	return ob_get_clean();
}


function via_classement_woocommerce_total_orders_semaine() { ?>
	<?php
	$semaine = new WP_Query( array( 
	'post_type' => 'shop_order', 
	'post_status' => 'publish',
	'posts_per_page'  => -1,			
	   'date_query'     => array(
		   array(
		  'after' => '1 week ago',
		  'inclusive' => true,
		   )
	)
	));
	$num = $semaine->post_count; 
	echo'<span class="numberCircle">';
	echo $num;
	echo'</span>'; 
}


function via_classement_woocommerce_total_orders_jour() { 
	// today
    $after_date = date( 'Y-m-d');
	$jour = new WP_Query( array( 
	'post_type' => 'shop_order', 
	'post_status' => 'publish',
	'posts_per_page'  => -1,			
	   'date_query'     => array(
		   array(
		   'day' => date( 'd' )
		   )
	)
	));
	$num = $jour->post_count; 
	echo'<span class="numberCircle">';
	echo $num;
	echo'</span>'; 
}

////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////// List Orders by Date ///////////////////////////////////////////

function via_classement_woocommerce_total_orders_by_date() {

    global $wpdb;

    $date_from = '1 week ago';
    $date_to = '1 days ago';

    $result = $wpdb->get_results( "
        SELECT * FROM $wpdb->posts
        WHERE post_type = 'shop_order'
        AND post_status = 'wc-completed' OR post_status = 'wc-processing'
        AND post_date BETWEEN '{$date_from}  00:00:00' AND '{$date_to} 23:59:59'
    " );

    echo '<ul>';

    foreach($result as $value) {

        // Getting WC order object
        $order = wc_get_order( $value->ID );

        // For example displaying order number and status
        echo '<li>Order #'.$order->id. ' Statut : ' . $order->get_status() . '</li>';
    }
    echo '</ul>';
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                             // Functions Coupons //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function via_classement_woocommerce_total_coupons() {
	?>
	<?php
	$semaine = new WP_Query( array( 
	'post_type' => 'shop_coupon', 
	'post_status' => array ('publish', 'pending', 'draft', 'auto-draft', 'future', 'private', 'inherit', 'trash')
	));
	echo '<span class="numberCircle">';
	$num = $semaine->post_count; 
	echo $num;
	echo '</span>';

}

function via_classement_woocommerce_total_coupons_year($year) {
	?>
	<?php
	$semaine = new WP_Query( array( 
	'post_type' => 'shop_coupon', 
	'post_status' => 'publish',
	'posts_per_page'  => -1,			
	'orderby' => 'date', 
	'order' => 'DESC', 
	   'date_query' => array( 
		array( 'year' => date( $year )  
	))	
	));
	echo '<span class="numberCircle">';
	$num = $semaine->post_count; 
	echo $num;
	echo '</span>';
}


function via_classement_woocommerce_total_coupons_graphique($year) {
	?>
	<?php
	$semaine = new WP_Query( array( 
	'post_type' => 'shop_coupon', 
	'post_status' => 'publish',
	'posts_per_page'  => -1,			
	'orderby' => 'date', 
	'order' => 'DESC', 
	   'date_query' => array( 
		array( 'year' => date( $year )  
	))	
	));
	$num = $semaine->post_count; 
	return $num;
}

function via_classement_woocommerce_total_coupons_semaine() { ?>
	<?php
	$couponsemaine = new WP_Query( array( 
	'post_type' => 'shop_coupon', 
	'post_status' => 'publish',
	'posts_per_page'  => -1,			
	'orderby' => 'date', 
	'order' => 'DESC', 
	   'date_query'     => array(
		   array(
		   'after' => '1 week ago'
		   )
	)
	));
	$num = $couponsemaine->post_count; 
	echo'<span class="numberCircle">';
	echo $num;
	echo'</span>'; 
}

function via_classement_woocommerce_total_coupons_jour() { ?>
	<?php
	$couponjour = new WP_Query( array( 
	'post_type' => 'shop_coupon', 
	'post_status' => 'publish',
	'posts_per_page'  => -1,			
	'orderby' => 'date', 
	'order' => 'DESC', 
	   'date_query'     => array(
		   array(
		   'day' => date( 'd' )
		   )
	)
	));
	$num = $couponjour->post_count; 
	echo'<span class="numberCircle">';
	echo $num;
	echo'</span>'; 
}

function via_classement_woocommerce_total_coupons_en_ligne($statut) { ?>
	<?php
	$args = new WP_Query( array( 
	'post_type'        => 'shop_coupon',
	'post_status'      => $statut,
	));
	$num = $args->post_count; 
	echo'<span class="numberCircle">';
	echo $num;
	echo'</span>'; 
}

function via_classement_woocommerce_total_coupons_by_title($statut) { ?>
	<?php
	$i = 1;
	$args = array(
		'posts_per_page'   => 5,
		'orderby'          => 'title',
		'order'            => 'asc',
		'post_type'        => 'shop_coupon',
		'post_status'      => $statut,
	);
		
	$coupons = get_posts( $args );
	$coupon_names = array();
	foreach ( $coupons as $coupon ) {
		// Get the name for each coupon post
		$coupon_name = $coupon->post_title;
		array_push( $coupon_names, $coupon_name );
		echo '<span class="span-color-results">';
		echo $i . '&nbsp;-&nbsp;' . $coupon_name;
		echo '</span>';
		echo '<br />';
	$i++;
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                            // Fonction calcul pourcentage //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Assurer vous que le nom de cette fonction ne soit pas utiliser
function percent_classement($num_amount, $num_total) {
	$count1 = $num_amount / $num_total;
	$count2 = $count1 * 100 * 2.5;
	// Remplacer le 2 par 0 si vous ne voulez pas de d�cimales
	$count = number_format($count2, 2);
	echo $count;
}

// Assurer vous que le nom de cette fonction ne soit pas utiliser
function percent_classement_year($num_amount_year, $num_total_year) {
	$count1 = $num_amount_year / $num_total_year;
	$count2 = $count1 * 100 * 2.5;
	// Remplacer le 2 par 0 si vous ne voulez pas de d�cimales
	$count = number_format($count2, 2); 
	echo $count;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Fonction identique pour chaque mois ( Hauteur pixel batonnet % )
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function resultspourcentmonth($year, $month) {
	$options = get_option('via_woocommerce_classement_settings');
	$getchiffreoption = $options ['via_woocommerce_classement_chiffre_affaires'];
	$num_amount = via_classement_woocommerce_total_sells_by_month($year=$year,$month=$month, $day='1');
	$num_total = $getchiffreoption;
	$result = percent_classement ($num_amount, $num_total) .'px;';
	echo $result;
}

function resultspourcentyear($year) {
	$options = get_option('via_woocommerce_classement_settings');
	$getchiffreoption = $options ['via_woocommerce_classement_chiffre_affaires_comparatif_annuel'];
	$num_amount_year = via_classement_woocommerce_total_sells_by_year($year=$year);
	$num_total_year = $getchiffreoption;
	$result = percent_classement_year($num_amount_year, $num_total_year) .'px;';
	echo $result;
}

function resultspourcentyearrefunded($year) {
	$options = get_option('via_woocommerce_classement_settings');
	$getchiffreoption = $options ['via_woocommerce_classement_chiffre_affaires_comparatif_annuel'];
	$num_amount_year = via_classement_woocommerce_total_sells_by_year_refunded($year=$year);
	$num_total_year = $getchiffreoption;
	$result = percent_classement_year($num_amount_year, $num_total_year) .'px;';
	echo $result;
}

function chiffre_affaire_graph($pourcent = '', $divisible) {
	//$substensce = 5000;
	//$num_substensce = $substensce ['via_woocommerce_classement_chiffre_affaires'] * $pourcent / $divisible ;
	
	$divisible = 100;
    $options = get_option('via_woocommerce_classement_settings');
	$num_total = $options ['via_woocommerce_classement_chiffre_affaires'] * $pourcent / $divisible ; 
	echo $num_total;
	 
	//if (get_option('via_woocommerce_classement_settings') ) {
	    //echo $num_total;
	//}
	//else {
		//echo $num_substensce;
	//}
}

function chiffre_affaire_graph_comparatif_annuel($pourcent = '', $divisible) {
	$divisible = 100;
    $options = get_option('via_woocommerce_classement_settings');
	$num_total_year = $options ['via_woocommerce_classement_chiffre_affaires_comparatif_annuel'] * $pourcent / $divisible ; 
	echo $num_total_year;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                          // Trois fonctions permettant d'afficher le % de progres journalier//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function via_classement_woocommerce_total_sells_by_day() {
	global $wpdb;
	$today = date('Y-m-d');
	$tomorrow  = date('Y-m-d', strtotime('+24 hours'));
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$today 00:00:00' AND '$tomorrow 00:00:00'
	" ) );
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol();
}

function via_classement_woocommerce_total_sells_yesterday() {
	global $wpdb;
	$today = date('Y-m-d');
	$yesterday = date('Y-m-d',strtotime("-1 days"));
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$yesterday 00:00:00' AND '$today 00:00:00'
	" ) );
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
}

function comparatif_pourcent_ventes_jour() {
    $ventesdujour = via_classement_woocommerce_total_sells_by_day();
	$venteshier = via_classement_woocommerce_total_sells_yesterday();
	
	$c = $ventesdujour - $venteshier;
	$d = ($c * 100) / $ventesdujour;
	
	if ($d > 0) {
	return '(&nbsp;' . number_format((float) $d, 2, '.', '') . '&nbsp;%&nbsp;)';
	}
	elseif ($d < 0) {
	return '(&nbsp;' . number_format((float) $d, 2, '.', '') . '&nbsp;%&nbsp;)';
	}
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                          // Trois fonctions permettant d'afficher le % de progres Mensuel //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



function via_classement_woocommerce_total_sells_by_month_result_general_pourcent() {
	global $wpdb;
	$year = date('Y');
	$month = date('m');
	$day = date('d');
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$year-$month-01 00:00:00' AND '$year-$month-31 00:00:00'
	" ) );
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
}

function via_classement_woocommerce_total_sells_by_last_month_result_general_pourcent() {
	global $wpdb;
	$year = date('Y');
	$month = date('m', strtotime('-30 days'));
	$day = date('d');
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$year-$month-01 00:00:00' AND '$year-$month-31 00:00:00'
	" ) );
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
}


function comparatif_pourcent_ventes_mensuel() {
    $ventesdujour = via_classement_woocommerce_total_sells_by_month_result_general_pourcent();
	$venteshier = via_classement_woocommerce_total_sells_by_last_month_result_general_pourcent();
	
	$c = $ventesdujour - $venteshier;
	$d = ($c * 100) / $ventesdujour;
	
	if ($d > 0) {
	return ' (&nbsp;+&nbsp;' . number_format((float) $d, 2, '.', '') . '&nbsp;%&nbsp;)';
	}
	elseif ($d < 0) {
	return ' (&nbsp;-&nbsp;' . number_format((float) $d, 2, '.', '') . '&nbsp;%&nbsp;)';
	}
}

function via_classement_woocommerce_total_sells_by_year_result_general_comparatif($year) {
	global $wpdb;
	$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "
	SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	WHERE meta.meta_key = '_order_total'
	AND posts.post_type = 'shop_order'
	AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
	AND posts.post_date BETWEEN '$year-01-01 00:00:00' AND '$year-12-31 00:00:00'
	" ) );
	return number_format((float) $order_totals->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
}


function comparatif_pourcent_ventes_year() {
    $ventesdujour = via_classement_woocommerce_total_sells_by_year_result_general_comparatif('2016');
	$venteshier = via_classement_woocommerce_total_sells_by_year_result_general_comparatif('2015');
	
	$c = $ventesdujour - $venteshier;
	$d = ($c * 100) / $ventesdujour;
	
	if ($d > 0) {
	return '(&nbsp;+&nbsp;' . number_format((float) $d, 2, '.', '') . '&nbsp;%&nbsp;)';
	}
	elseif ($d < 0) {
	return '&nbsp;( &nbsp;' . number_format((float) $d, 2, '.', '') . '&nbsp;%&nbsp;)';
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Sales calculate % and go to objectives graphs //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function resultspourcentyearobjectifsventes($year) {
	$options = get_option('via_woocommerce_classement_settings');
	$getchiffreoption = $options ['via_woocommerce_classement_objectifs_ventes'];
	$num_amount_year = via_classement_woocommerce_total_sells_by_year($year=$year);
	$num_total_year = $getchiffreoption;
	$result = percent_classement_year_objectifs_ventes($num_amount_year, $num_total_year) .'px;';
	echo $result;
}

// Assurer vous que le nom de cette fonction ne soit pas utiliser
function percent_classement_year_objectifs_ventes($num_amount_year, $num_total_year) {
	$count1 = $num_amount_year / $num_total_year;
	$count2 = $count1 * 100 * 2.5;
	// Remplacer le 2 par 0 si vous ne voulez pas de d�cimales
	$count = number_format($count2, 2); 
	echo $count;
}

function chiffre_affaire_graph_comparatif_annuel_objectifs ($pourcent = '', $divisible) {
	$divisible = 100;
    $options = get_option('via_woocommerce_classement_settings');
	$num_total_year = $options ['via_woocommerce_classement_objectifs_ventes'] * $pourcent / $divisible ; 
	echo $num_total_year;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // SCustomers calculate % and go to objectives graphs //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function resultspourcentyearobjectifsclients($year) {
	$options = get_option('via_woocommerce_classement_settings');
	$getchiffreoption = $options ['via_woocommerce_classement_objectifs_clients'];
	$num_amount_year = via_classement_woocommerce_total_user_registred_graphique($year=$year);
	$num_total_year = $getchiffreoption;
	$result = percent_classement_year_objectifs_clients($num_amount_year, $num_total_year) .'px;';
	echo $result;
}

// Assurer vous que le nom de cette fonction ne soit pas utiliser
function percent_classement_year_objectifs_clients($num_amount_year, $num_total_year) {
	$count1 = $num_amount_year / $num_total_year;
	$count2 = $count1 * 100 * 2.5;
	// Remplacer le 2 par 0 si vous ne voulez pas de d�cimales
	$count = number_format($count2, 2); 
	echo $count;
}

function chiffre_affaire_graph_comparatif_annuel_objectifs_clients ($pourcent = '', $divisible) {
	$divisible = 100;
    $options = get_option('via_woocommerce_classement_settings');
	$num_total_year = $options ['via_woocommerce_classement_objectifs_clients'] * $pourcent / $divisible ; 
	echo $num_total_year;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Orders calculate % and go to objectives graphs //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function resultspourcentyearobjectifscommandes($year) {
	$options = get_option('via_woocommerce_classement_settings');
	$getchiffreoption = $options ['via_woocommerce_classement_objectifs_commandes'];
	$num_amount_year = via_classement_woocommerce_total_orders_all_graphique($year=$year);
	$num_total_year = $getchiffreoption;
	$result = percent_classement_year_objectifs_commandes($num_amount_year, $num_total_year) .'px;';
	echo $result;
}

// Assurer vous que le nom de cette fonction ne soit pas utiliser
function percent_classement_year_objectifs_commandes($num_amount_year, $num_total_year) {
	$count1 = $num_amount_year / $num_total_year;
	$count2 = $count1 * 100 * 2.5;
	// Remplacer le 2 par 0 si vous ne voulez pas de d�cimales
	$count = number_format($count2, 2); 
	echo $count;
}

function chiffre_affaire_graph_comparatif_annuel_objectifs_commandes ($pourcent = '', $divisible) {
	$divisible = 100;
    $options = get_option('via_woocommerce_classement_settings');
	$num_total_year = $options ['via_woocommerce_classement_objectifs_commandes'] * $pourcent / $divisible ; 
	echo $num_total_year;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Coupons calculate % and go to objectives graphs //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function resultspourcentyearobjectifscoupons($year) {
	$options = get_option('via_woocommerce_classement_settings');
	$getchiffreoption = $options ['via_woocommerce_classement_objectifs_coupons'];
	$num_amount_year = via_classement_woocommerce_total_coupons_graphique($year=$year);
	$num_total_year = $getchiffreoption;
	$result = percent_classement_year_objectifs_coupons($num_amount_year, $num_total_year) .'px;';
	echo $result;
}

// Assurer vous que le nom de cette fonction ne soit pas utiliser
function percent_classement_year_objectifs_coupons($num_amount_year, $num_total_year) {
	$count1 = $num_amount_year / $num_total_year;
	$count2 = $count1 * 100 * 2.5;
	// Remplacer le 2 par 0 si vous ne voulez pas de d�cimales
	$count = number_format($count2, 2); 
	echo $count;
}

function chiffre_affaire_graph_comparatif_annuel_objectifs_coupons ($pourcent = '', $divisible) {
	$divisible = 100;
    $options = get_option('via_woocommerce_classement_settings');
	$num_total_year = $options ['via_woocommerce_classement_objectifs_coupons'] * $pourcent / $divisible ; 
	echo $num_total_year;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Shipping calculate % and go to objectives graphs //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function resultspourcentyearobjectifsshipping($year) {
	$options = get_option('via_woocommerce_classement_settings');
	$getchiffreoption = $options ['via_woocommerce_classement_objectifs_shipping'];
	$num_amount_year = via_classement_woocommerce_get_total_shipping_annuel($year=$year);
	$num_total_year = $getchiffreoption;
	$result = percent_classement_year_objectifs_shipping($num_amount_year, $num_total_year) .'px;';
	echo $result;
}

// Assurer vous que le nom de cette fonction ne soit pas utiliser
function percent_classement_year_objectifs_shipping($num_amount_year, $num_total_year) {
	$count1 = $num_amount_year / $num_total_year;
	$count2 = $count1 * 100 * 2.5;
	// Remplacer le 2 par 0 si vous ne voulez pas de d�cimales
	$count = number_format($count2, 2); 
	echo $count;
}

function chiffre_affaire_graph_comparatif_annuel_objectifs_shipping ($pourcent = '', $divisible) {
	$divisible = 100;
    $options = get_option('via_woocommerce_classement_settings');
	$num_total_year = $options ['via_woocommerce_classement_objectifs_shipping'] * $pourcent / $divisible ; 
	echo $num_total_year;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Show Paiements transaction results //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function via_classement_woocommerce_get_paiements_way() {
	global $wpdb;	
	$query = "
		SELECT 
		payment_method_title.meta_value as 'payment_method_title'
		
		,SUM(order_total.meta_value) as 'order_total'
		,count(*) as order_count
		FROM {$wpdb->prefix}posts as posts	";		
		

		
	$query .= "	LEFT JOIN  {$wpdb->prefix}postmeta as order_total ON order_total.post_id=posts.ID ";

	$query .= "	LEFT JOIN  {$wpdb->prefix}postmeta as payment_method_title ON payment_method_title.post_id=posts.ID ";


	$query .=	"WHERE 1=1 ";
		
	$query .= " AND posts.post_type ='shop_order' ";
	$query .= " AND order_total.meta_key ='_order_total' ";
	$query .= " AND payment_method_title.meta_key ='_payment_method_title' ";
	$query .= " GROUP BY payment_method_title.meta_value";

	$data = $wpdb->get_results($query);		

	//$this->print_data($data);

	if (count($data)>0){
	?>
	<table style="width:100%">
		<tr>
			<th style="padding:0 0 20px 0; font-size:17px; border-bottom:1px solid #90949c"><?php _e('Payment Methods', 'woocommerce-classement'); ?></th>
			<th style="padding:0 0 20px 0; font-size:17px; border-bottom:1px solid #90949c"><?php _e('Number of Order(s)', 'woocommerce-classement'); ?></th>
			<th style="padding:0 0 20px 0; font-size:17px; border-bottom:1px solid #90949c"><?php _e('Total', 'woocommerce-classement'); ?></th>
		</tr>
	<?php
	foreach($data  as $k=>$v){
	?>
		<tr>
			<td style="text-align:center; padding:10px 0; width:33%; font-size:17px">
			<?php echo $v->payment_method_title; ?>
			</td>
			<td style="text-align:center; padding:10px 0; width:33%; font-size:17px"><?php echo $v->order_count; ?></td>
		   <td style="text-align:center; padding:10px 0; width:33%; font-size:17px"><?php echo woocommerce_price($v->order_total); ?></td>
		</tr>
	<?php	
	}
	?>
	  </table>
	<?php	
}else{
	echo "No record found...";	
}
	
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Show list last orders content //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function via_classement_woocommerce_get_list_products_orders($order) {
		
		global $woocommerce;
		// 0 today
		$filters = array(
		'post_type' => 'shop_order',
		'post_status' => 'publish',
		'posts_per_page' => 50, // or -1 for all
		);

		$loop = new WP_Query($filters);

		
		echo '<div class="cutomers-by-sales">';
			echo '<div style="overflow-x:auto;">';
				echo'<table>';
				
				echo'<tr>';
				echo'<th>'; _e('Date', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Product ID', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Product Name', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Product Type', 'woocommerce-classement');'</th>';
				//echo'<th>'; _e('Shipping Cost', 'woocommerce-classement');'</th>';
				echo'</tr>';
		
		
		        while ($loop->have_posts()) {
				$loop->the_post();
				$order = new WC_Order($loop->post->ID);
			   
					foreach ($order->get_items() as $key => $lineItem) {

						echo'<tr>';
			            echo'<td>'; echo the_time('d/m/Y'); '</td>';
						echo'<td>' . '' . $lineItem['product_id'] . '</td>';
						echo'<td>' . '' . $lineItem['name'] . '</td>';
						echo'<td>'; if ($lineItem['variation_id']) {
						_e ('Variable Product', 'woocommerce-classement') . '<br>';
						} 
						else {
						_e ('Simple Product', 'woocommerce-classement') . '<br>';
						}; '</td>';
						
						//echo'<td>';
				        // echo $order->calculate_shipping() . '&nbsp;' . get_woocommerce_currency_symbol();
						//'</td>';

						echo'</tr>'; 
			
					}
				}
				
                echo'</table>';
		    echo'</div>';
		echo'</div>';
		echo'<div class="via-woocommerce-classement-clear"></div>';
		echo'<div class="col span_8_of_8">';
			echo'<div class="orderslink">';
			    //echo '<a href="");>+</a>';
			echo'</div>';
		echo'</div>';

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Get shipping total for an order //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function via_classement_woocommerce_calculate_shipping() {

	global $woocommerce;
	$shipping_total = 0;

	foreach ( $this->get_shipping_methods() as $shipping ) {
		$shipping_total += $shipping['cost'];
	}

	$this->set_total( $shipping_total, 'shipping' );

	return $this->get_total_shipping();
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Get shipping total for all orders //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
function via_classement_woocommerce_get_total_shipping() {
	global $wpdb;
	$shipping_total = apply_filters( 'woocommerce_reports_sales_overview_shipping_total', $wpdb->get_var( "
	SELECT SUM(meta.meta_value) AS total_sales FROM {$wpdb->posts} AS posts
 
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	LEFT JOIN {$wpdb->term_relationships} AS rel ON posts.ID=rel.object_ID
	LEFT JOIN {$wpdb->term_taxonomy} AS tax USING( term_taxonomy_id )
	LEFT JOIN {$wpdb->terms} AS term USING( term_id )
 
	WHERE 	meta.meta_key 		= '_order_shipping'
	AND 	posts.post_type 	= 'shop_order'
	AND 	posts.post_status 	= 'publish'
	AND 	tax.taxonomy		= 'shop_order_status'
	AND		term.slug			IN ('" . implode( "','", apply_filters( 'woocommerce_reports_order_statuses', array( 'completed', 'processing', 'on-hold' ) ) ) . "')
" ) );
    echo '<span class="numberCircle">'; 
	return number_format((float) $shipping_total->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
	echo '</span>';
}

function via_classement_woocommerce_get_total_shipping_annuel($year) {
	global $wpdb;
	$shipping_total = apply_filters( 'woocommerce_reports_sales_overview_shipping_total', $wpdb->get_var( "
	SELECT SUM(meta.meta_value) AS total_sales FROM {$wpdb->posts} AS posts
 
	LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id
	LEFT JOIN {$wpdb->term_relationships} AS rel ON posts.ID=rel.object_ID
	LEFT JOIN {$wpdb->term_taxonomy} AS tax USING( term_taxonomy_id )
	LEFT JOIN {$wpdb->terms} AS term USING( term_id )
 
	WHERE 	meta.meta_key 		= '_order_shipping'
	AND 	posts.post_type 	= 'shop_order'
	AND 	posts.post_status 	= 'publish'
	AND 	tax.taxonomy		= 'shop_order_status'
	AND		term.slug			IN ('" . implode( "','", apply_filters( 'woocommerce_reports_order_statuses', array( 'completed', 'processing', 'on-hold' ) ) ) . "')
    AND posts.post_date BETWEEN '$year-01-01 00:00:00' AND '$year-12-31 00:00:00'
" ) ); 
	return number_format((float) $shipping_total->total_sales, 2, '.', '') . '&nbsp;' . get_woocommerce_currency_symbol(); 
} 


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                    // Show color of the graphics if user select the color //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function via_classement_woocommerce_get_color_graphique_regular() {
	$options = get_option('via_woocommerce_classement_settings'); 
	if ( isset($options['via_woocommerce_classement_select_couleurs_graphs']) 
		&& ($options['via_woocommerce_classement_select_couleurs_graphs'] == 1) ){
			echo 'green';
	}
	elseif ( isset($options['via_woocommerce_classement_select_couleurs_graphs']) 
		&& ($options['via_woocommerce_classement_select_couleurs_graphs'] == 2) ){
			echo 'blue';
	}
	elseif ( isset($options['via_woocommerce_classement_select_couleurs_graphs']) 
		&& ($options['via_woocommerce_classement_select_couleurs_graphs'] == 3) ){
			echo 'red';
	}
}

function get_color_graphique_objectifs() {
	$options = get_option('via_woocommerce_classement_settings'); 
	if ( isset($options['via_woocommerce_classement_objectifs_color_graphique']) 
		&& ($options['via_woocommerce_classement_objectifs_color_graphique'] == 1) ){
			echo 'green';
	}
	elseif ( isset($options['via_woocommerce_classement_objectifs_color_graphique']) 
		&& ($options['via_woocommerce_classement_objectifs_color_graphique'] == 2) ){
			echo 'blue';
	}
	elseif ( isset($options['via_woocommerce_classement_objectifs_color_graphique']) 
		&& ($options['via_woocommerce_classement_objectifs_color_graphique'] == 3) ){
			echo 'red';
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                              // Get customer loyal results (if count orders > 3) //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function via_classement_woocommerce_wc_get_customer_orders($user_id) {
    
	global $wpdb;
	$options = get_option('via_woocommerce_classement_settings');
	$count_orders_loyal_users = $options ['via_woocommerce_classement_users_loyal_count'];
    // Get all customer orders
    $customer_orders = get_posts( array(
        'numberposts' => -1,
        'meta_key'    => '_customer_user',
        'meta_value'  => get_current_user_id(),
        'post_type'   => wc_get_order_types(),
        'post_status' => array_keys( wc_get_order_statuses() ),
    ) );
    
    $customer = wp_get_current_user();
    
    // Order count for a "loyal" customer
    $loyal_orders_count = $count_orders_loyal_users;
    
	// Display our notice if the customer has at least 5 orders
    if ( count( $customer_orders ) >= $loyal_orders_count ) {
        _e('Loyal Customer','woocommerce-classement');
    }
	else {
	    _e('Not again','woocommerce-classement');
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                              // Get customer list results orders //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
function via_classement_woocommerce_list_customers_results($user_id) { 
        global $wpdb;
		$blogusers = get_users( 'role=customer' );
		
		echo '<div class="cutomers-by-sales">';
		
			echo '<div style="overflow-x:auto;">';
			
				echo'<table>';
				
				echo'<tr>';
				echo'<th>'; _e('Customer since', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Name', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Surname', 'woocommerce-classement');'</th>';
				//echo'<th>'; _e('Country', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('City', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Phone Number', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Email', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Count Orders', 'woocommerce-classement'); '</th>';
				echo'<th>'; _e('Total Spent', 'woocommerce-classement'); '</th>';
				//echo'<th>'; _e('Total Shipping', 'woocommerce-classement'); '</th>';
				//echo'<th>'; _e('Loyal Customer', 'woocommerce-classement'); '</th>';
				echo'</tr>';
				
				// Array of WP_User objects.
				foreach ( $blogusers as $user ) {
				
				echo'<tr>';
				echo'<td>'; 
				$udata = get_userdata( $user->ID );
				$registered = $udata->user_registered;
				$message = '' . date( 'd M Y', strtotime( $registered ) );
				echo $message; 
				'</td>';
				echo'<td>'; _e( $user->billing_last_name ); '</td>';
				echo'<td>'; _e( $user->billing_first_name ); '</td>';
				//echo'<td>'; _e( $user->billing_country ); '</td>';
				echo'<td>'; _e( $user->billing_city );'</td>';
				echo'<td>';  _e( $user->billing_phone ); '</td>';
				echo'<td>'; _e( $user->user_email ); '</td>';
				echo'<td>'; echo wc_get_customer_order_count( $user->ID ); '</td>';
				echo'<td>'; echo wc_price(wc_get_customer_total_spent( $user->ID  ));'</td>';
				//echo'<td>';'</td>';
				//echo'<td>'; echo via_classement_woocommerce_wc_get_customer_orders($user_id); '</td>';
	
				echo'</tr>'; 
		
				} 
				echo'</table>';
				
			echo'</div>';
			
		echo'</div>';
		
		echo'<div class="via-woocommerce-classement-clear"></div>';
		echo'<div class="col span_8_of_8">';
			echo'<div class="orderslink">';
			    //echo '<a href="");>+</a>';
			echo'</div>';
		echo'</div>';
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                              // Get all orders list //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	

function via_classement_woocommerce_list_orders_all() { ?>

<?php
global $woocommerce;  
$params = array(
'post_type'       =>'shop_order',
'post_status'    => 'publish',
'posts_per_page' =>  50,  
'order' => 'DESC',
'tax_query' => array( 
array( 'taxonomy' => 'shop_order_status',
	   'field' => 'slug', 
	   'terms' => array ('Pending' , 'Failed' , 'Processing' , 'Refunded', 'On-Hold' , 'Cancelled' , 'Completed')
	  ) 
	)           
);
$orders = new WP_Query($params); 
?>

<div class="cutomers-by-sales">
		
			<div style="overflow-x:auto;">
			
				<table>
				
					<thead>
					
						<tr>
						    <th><?php _e('Date', 'woocommerce-classement'); ?></th>
							<th><?php _e('E-mail', 'woocommerce-classement'); ?></th>
							<th><?php _e('Tel', 'woocommerce-classement'); ?></th>
							<th><?php _e('Order ID', 'woocommerce-classement'); ?></th>
							<th><?php //_e('Sku', 'woocommerce-classement'); ?></th>
							<th><?php _e('Product', 'woocommerce-classement'); ?></th>
							<th><?php _e('Price', 'woocommerce-classement'); ?></th>
							<th><?php _e('Status', 'woocommerce-classement'); ?></th>
						</tr>
					</thead>
					<tbody>     

                    <?php if ($orders->have_posts()) : ?> 
                    <?php 
					while ($orders->have_posts()) : $orders->the_post(); 
					$order_id = $orders->post->ID;
					$order = new WC_Order($order_id);
					?>					

                    <tr>
							
							<td>
							
								<?php echo the_time('d/m/Y'); ?>
								
							</td> 
							
							<td>
								<?php 
								// Email
								 if ($order->billing_email) : ?><?php echo $order->billing_email; ?><?php endif; ?>
							</td> 
							
							<td>
								<?php 
								 // Tel
								 if ($order->billing_phone) : ?><?php echo $order->billing_phone; ?><?php endif; ?>
							</td>
							             
										 
							<td>
									<a href="<?php echo esc_url( home_url('/' ) ); ?>wp-admin/post.php?post=<?php echo $order->id; ?>&action=edit" target="_blank">
									<?php echo $order->id; ?></a>
							</td>
							
							<td>
								<?php
									// SKU
									//if (sizeof($order->get_items())>0)  { foreach($order->get_items() as $item) 
									//{ $_product = get_product( $item['product_id'] );   echo '' . $_product->sku . '';   }  }
								?> 
							</td>
							
							<td>
								<?php
									// Product Name
								   if (sizeof($order->get_items())>0)   { foreach($order->get_items() as $item) 
								   { $_product = get_product( $item['product_id'] ); echo '' . $item['name'] . '';  } }
								?>
							</td>                   
						
							<td>
								<?php 
								// The purchase value + the price format
								if ($order->order_total): $priceformat=($order->order_total);?>
								<?php echo $finalprice=number_format($priceformat, 2, '.', '.'); ?>
								<?php echo get_woocommerce_currency_symbol(); ?>
								<?php endif; ?>
							</td>
							
							<td>
								<?php 
								// Displays the status of the client request
								 if ($order->status) : ?><?php echo ucfirst($order->status); ?><?php endif; ?>
							</td>
							
					    </tr> 
						
						<?php endwhile; ?>
						
						<?php wp_reset_postdata(); ?>
						
					</tbody>
							
				</table>

			</div>

		</div>
		
		<div class="via-woocommerce-classement-clear"></div>
		
        <div class="col span_8_of_8">
		
			<div class="orderslink">
			
			    <?php //echo '<a href="#">+</a>'; ?>
			
			</div>
		
		</div>
		
<?php else:  ?>

<p>
	 <?php _e( 'No orders currently', 'woocommerce-classement'); ?>
</p>

<?php endif; ?>

<?php }



function via_classement_woocommerce_list_orders_by_id() { ?>
    
	<?php
		global $wpdb;
		$options = get_option('via_woocommerce_classement_settings');
		$productid = $options ['via_woocommerce_classement_queries_by_product_id'];		
		$product_id = $productid; 
		$result = "SELECT order_id FROM {$wpdb->prefix}woocommerce_order_itemmeta woim 
		LEFT JOIN {$wpdb->prefix}woocommerce_order_items oi 
		ON woim.order_item_id = oi.order_item_id 
		WHERE meta_key = '_product_id' AND meta_value = %d
		GROUP BY order_id;";
		$order_ids = $wpdb->get_col( $wpdb->prepare( $result, $product_id ) );
		if( $order_ids ) {
			$args = array(
			'post_type'       =>'shop_order',
			'post__in'   => $order_ids,
			'post_status'    => 'publish',
			'posts_per_page' =>  50,
			'order'          => 'DESC',             
			'tax_query' => array( 
			array( 'taxonomy' => 'shop_order_status',
				   'field' => 'slug',
				   'terms' => array ('Pending' , 'Failed' , 'Processing' , 'Completed', 'On-Hold' , 'Cancelled' , 'Refunded')
				  ) 
				)           
			);
			$orders = new WP_Query( $args );
			}
		?>               
		<div class="cutomers-by-sales">
		
			<div style="overflow-x:auto;">
			
				<table>
				
					<thead>
					
						<tr>
							<th><?php _e('Order ID', 'woocommerce-classement'); ?></th>
							<th><?php _e('E-mail', 'woocommerce-classement'); ?></th>
							<th><?php _e('Tel', 'woocommerce-classement'); ?></th>
							<th><?php _e('State', 'woocommerce-classement'); ?></th>
							<th><?php //_e('Sku', 'woocommerce-classement'); ?></th>
							<th><?php _e('Product', 'woocommerce-classement'); ?></th>
							<th><?php _e('Price', 'woocommerce-classement'); ?></th>
							<th><?php _e('Status', 'woocommerce-classement'); ?></th>
						</tr>
					</thead>
					<tbody>
                        	
                        <?php if ($orders->have_posts()) : ?>
						
						<?php
						while ( $orders->have_posts() ) : $orders->the_post(); 
						$order_id = $orders->post->ID; 
						$order = new WC_Order($order_id);            
						?> 
						<tr>
							
							<td>
								<?php
								   // Id Order 
								 if ($order->id) : ?>
									<a href="<?php echo esc_url( home_url('/' ) ); ?>wp-admin/post.php?post=<?php echo $order->id; ?>&action=edit" target="_blank">
									<?php echo $order->id; ?></a>
									<?php endif;?>
							</td>
							
							<td>
								<?php 
								// Email
								 if ($order->billing_email) : ?><?php echo $order->billing_email; ?><?php endif; ?>
							</td> 
							
							 <td>
								<?php 
								 // Tel
								 if ($order->billing_phone) : ?><?php echo $order->billing_phone; ?><?php endif; ?>
							</td>
							             
							
							<td>
								<?php 
								// State
								if ($order->billing_state): ?><?php echo $order->billing_state; ?><?php endif; ?>
							</td>
							
							
							<td>
								<?php
									// SKU
									//if (sizeof($order->get_items())>0)  { foreach($order->get_items() as $item) 
									//{ $_product = get_product( $item['product_id'] );   echo '' . $_product->sku . '';   }  }
								?> 
							</td>
							
							<td>
								<?php
									// Product Name
								   if (sizeof($order->get_items())>0)   { foreach($order->get_items() as $item) 
								   { $_product = get_product( $item['product_id'] ); echo '' . $item['name'] . '';  } }
								?>
							</td>                   
						
							<td>
								<?php 
								// The purchase value + the price format
								if ($order->order_total): $priceformat=($order->order_total);?>
								<?php echo $finalprice=number_format($priceformat, 2, ',', '.'); ?>
								<?php echo get_woocommerce_currency_symbol(); ?>
								<?php endif; ?>
							</td>
							
							<td>
								<?php 
								// Displays the status of the client request
								 if ($order->status) : ?><?php echo ucfirst($order->status); ?><?php endif; ?>
							</td>
							
					   </tr> 

					<?php endwhile; ?>
					
				    <?php wp_reset_query(); ?> 
					
					</tbody>
					
				</table>
				
			</div>
			
		</div>
		
		<div class="via-woocommerce-classement-clear"></div>

		<div class="col span_8_of_8">

			<div class="orderslink">

			    <?php //echo '<a href="#">+</a>'; ?>

			</div>

		</div>
		
<?php else:  ?>

<p>
	 <?php _e( 'No orders currently', 'woocommerce-classement'); ?>
</p>

<?php endif; ?>

<?php }

