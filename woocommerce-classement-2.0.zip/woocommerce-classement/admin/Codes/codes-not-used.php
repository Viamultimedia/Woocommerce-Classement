<?php	

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// Select List Products ///////////////////////////////////////
	
<?php
$i = 1;
$products = new WP_Query( array( 
'post_type' => array('product'),
'post_status' => 'publish',
'showposts'  => '500',		
'order' => 'DESC', 
));
?>
<select>
<?php while ($products->have_posts()) : $products->the_post(); ?>
<option value="volvo"><?php echo $i; ?><?php echo '&nbsp;-&nbsp;'; ?><?php the_title(); ?> - <?php echo $products->post->ID; ?></option>
<?php $i++; ?>
<?php wp_reset_query(); ?>
<?php endwhile; ?>
</select>