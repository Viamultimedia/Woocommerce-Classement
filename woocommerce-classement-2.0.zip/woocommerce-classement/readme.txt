=== Via Woocommerce Classement ===
Contributors: (Tony Breboin)
Tags: Woocommerce, ecommerce, e-commerce,
Requires at least: 4.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv3 or later License
URI: http://www.gnu.org/licenses/gpl-3.0.html
WC requires at least: 2.6
WC tested up to: 2.6